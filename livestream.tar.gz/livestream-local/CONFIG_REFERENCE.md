# Configuration and Credentials Reference

Every credential, variable, topic and endpoint in the livestreaming system.

---

## 1. Credentials — what exists and who holds it

| Credential | Held by | Used for | Rotation |
|---|---|---|---|
| **LiveKit API secret** | Stream API only | Signing viewer passes, verifying webhooks, managing ingresses | Change `LIVEKIT_API_SECRET` in `stack.env`, restart LiveKit and the Stream API. Issued passes stop working immediately |
| **Service API token** | BC | Calling the Stream API over HTTPS | Change `COMMANDER_API_TOKEN`, restart the Stream API, update BC |
| **MQTT service credential** | BC | Sending start/stop commands to any vehicle | `secure-mqtt.sh <host> add-service bc` |
| **MQTT vehicle credential** | One vehicle each | Receiving its own commands only | `secure-mqtt.sh <host> add-vehicle <vid>` |
| **Publish token** | One vehicle each | Publishing video into its own room | Delete and recreate the ingress, then re-run `provision` |
| **Viewer pass** | One viewer, 1 hour | Watching one vehicle's room | Expires on its own; request a new one |

Generate secrets with `openssl rand -hex 24`. None of these belong in source
control.

**The LiveKit API secret is the one that matters most.** Anyone holding it can
mint a pass for any vehicle in the fleet. It never leaves the Stream API — BC
receives only minted, room-scoped passes.

---

## 2. Server configuration — `stack.env`

### Identity and addressing

| Variable | Example | Notes |
|---|---|---|
| `HOST_IP` | `live.bullworkmobility.com` | The address vehicles and viewers use. LAN IP locally, hostname in production. Never `localhost` |
| `PUBLIC_HOST` | `live.bullworkmobility.com` | Set this to switch `start.sh` to the public LiveKit config (TURN on, external IP advertised). Leave empty for local |
| `LIVEKIT_WS_URL` | `wss://live.bullworkmobility.com` | What viewers connect to. Defaults to `ws://$HOST_IP:7880` if unset |
| `WHIP_BASE_URL` | `https://live.bullworkmobility.com/w` | Base for vehicle publish URLs. Defaults to `http://$HOST_IP:8080/w` |
| `STREAM_API_URL` | `https://live.bullworkmobility.com/api` | Used by `flow.sh`; BC needs the same value |
| `LIVEKIT_HTTP_URL` | `http://localhost:7880` | How the Stream API reaches LiveKit. Stays local — no need to change |

### Secrets

| Variable | Notes |
|---|---|
| `LIVEKIT_API_KEY` | Identifier, not a secret. `devkey` is fine |
| `LIVEKIT_API_SECRET` | Minimum 32 characters. Must match between LiveKit, the ingress and the Stream API |
| `COMMANDER_API_TOKEN` | What BC sends as `Authorization: Bearer <token>` |

### Ports

| Variable | Default | Purpose |
|---|---|---|
| `LIVEKIT_PORT` | 7880 | Signalling, HTTP/WS |
| `LIVEKIT_TCP_PORT` | 7881 | WebRTC TCP fallback |
| `LIVEKIT_UDP_START` / `_END` | 50100 / 50200 | Media to viewers |
| `WHIP_PORT` | 8070 | WHIP ingest HTTP |
| `WHIP_UDP_START` / `_END` | 7885 / 7895 | WHIP ingest media. Must be a range, never a single port |
| `COMMANDER_PORT` | 8095 | Stream API |
| `REDIS_PORT` | 6380 | Our own Redis. Not 6379 — a shared machine usually has one already |
| `VIEWER_PORT` | 8081 | Test viewer page |
| `MQTT_PORT` | 1883 / 8883 | 8883 once TLS is on |

### Behaviour

| Variable | Default | Meaning |
|---|---|---|
| `REDIS_URL` | `redis://localhost:6380/1` | Stream state. db 1; LiveKit uses db 0 of the same instance |
| `PUBLISH_TIMEOUT_S` | 25 | How long after `expect` before a silent vehicle becomes `FAILED_TO_START` |
| `VIEWER_TOKEN_TTL_S` | 3600 | Viewer pass lifetime |
| `RECONCILE_EVERY_S` | 30 | How often Redis is checked against LiveKit's real state |
| `IDLE_CLOSE_S` | 600 | A stream with no viewers for this long is closed by the server. Clients cannot be relied on to stop what they started |

---

## 3. Vehicle configuration — `vehicle.env`

### Identity

| Variable | Example | Notes |
|---|---|---|
| `VID` | `vehicle-01` | **Unique per physical vehicle.** Do not bake into a cloned disk image |

Must match `[A-Za-z0-9_-]`, 1-64 characters. The Stream API rejects
anything else.

### Connection

| Variable | Example | Notes |
|---|---|---|
| `MQTT_HOST` | `live.bullworkmobility.com` | Where the broker is |
| `MQTT_PORT` | `8883` | 1883 plain, 8883 TLS |
| `MQTT_USER` | `veh-vehicle-01` | From `secure-mqtt.sh add-vehicle` |
| `MQTT_PASS` | `<generated>` | Same source. Not stored anywhere else |
| `MQTT_TLS` | `true` | Must be true when using 8883 |

### Publishing

| Variable | Example | Notes |
|---|---|---|
| `WHIP_URL` | `https://live.../w/RygtuteWfBp3` | From the `provision` call. Set once at setup |
| `PUBLISH_TOKEN` | `RygtuteWfBp3` | Same call. It is the stream key |
| `STREAM_API_URL` | `https://live.../api` | Leave `WHIP_URL` empty and set this instead — the vehicle fetches its own publish URL using its `VID` |
| `PROVISION_TOKEN` | `<service token>` | Credential for that fetch. Makes `VID` the only per-vehicle value |
| `STUN_SERVER` | `stun://stun.l.google.com:19302` | Fine as is |
| `TURN_SERVER` | `turns://live.bullworkmobility.com:5349` | Empty on a LAN. **Required on mobile SIMs** |
| `ICE_GATHER_TIMEOUT_S` | `10` | Abort if ICE never completes |

### Video

| Variable | Default | Notes |
|---|---|---|
| `SOURCE` | `ros` | `test` (no camera), `uvc` (ZED as plain camera), `ros` (ZED wrapper topic) |
| `VIDEO_DEVICE` | `/dev/video0` | `uvc` mode only |
| `ZED_TOPIC` | `/zed/zed_node/rgb/image_rect_color` | `ros` mode only |
| `WIDTH` / `HEIGHT` | 1280 / 720 | Per eye. `uvc` opens the camera at double the width |
| `FPS` | 30 | |
| `BITRATE_KBPS` | 3000 | Lower this for constrained cellular uplink |

### Teleop

| Variable | Default | Notes |
|---|---|---|
| `CMD_VEL_TOPIC` | `/cmd_vel` | Where commands are republished. `ros` mode only |
| `MAX_LIN` / `MAX_ANG` | 1.0 / 1.5 | Clamped on the vehicle |
| `DEADMAN_S` | 0.5 | No command within this window sends a zero velocity |

---

## 4. MQTT reference

### Topics

| Topic | Direction | Published by | Subscribed by |
|---|---|---|---|
| `{vid}/command/livestream` | to vehicle | BC | Vehicle |
| `{vid}/command/teleop` | to vehicle | BC | Vehicle |
| `{vid}/status` | from vehicle | Vehicle | BC |

### Payloads

Start streaming — no payload needed, the vehicle knows where to publish:

```json
{"type": "CMD_LIVESTREAM_ENABLE"}
```

Optionally override the destination (useful during testing):

```json
{"type": "CMD_LIVESTREAM_ENABLE",
 "whip_url": "https://live.example.com/w/<key>",
 "publish_token": "<key>"}
```

Stop:

```json
{"type": "CMD_LIVESTREAM_DISABLE"}
```

Teleop — send at roughly 10 Hz; stopping the flow triggers the deadman:

```json
{"lin": 0.3, "ang": -0.1}
```

### Access control

After `secure-mqtt.sh`, each vehicle's credential is restricted to:

```
topic read  {vid}/command/#
topic write {vid}/status
```

So a vehicle cannot see or command any other vehicle, even with a SIM pulled
from it. BC's service credential can write `+/command/#` and read
`+/status`.

### Manual commands

```bash
# local, before TLS
mosquitto_pub -h $HOST -t vehicle-01/command/livestream \
  -m '{"type":"CMD_LIVESTREAM_ENABLE"}'

# after TLS and auth
mosquitto_pub -h live.bullworkmobility.com -p 8883 --capath /etc/ssl/certs \
  -u bc -P '<service-password>' \
  -t vehicle-01/command/livestream \
  -m '{"type":"CMD_LIVESTREAM_ENABLE"}'

# watch everything
mosquitto_sub -h $HOST -t '+/command/#' -v
```

---

## 5. Stream API reference

Base URL: `https://live.bullworkmobility.com/api`
Every request needs `Authorization: Bearer $COMMANDER_API_TOKEN`.

### `POST /{vid}/livestream/provision`

Once per vehicle, at setup. Idempotent.

```json
{"room": "vehicle-01",
 "ingress_id": "IN_5HdH7Mi6wvwE",
 "whip_url": "https://live.../w/RygtuteWfBp3",
 "publish_token": "RygtuteWfBp3"}
```

Put `whip_url` and `publish_token` into that vehicle's `vehicle.env`.

### `POST /{vid}/livestream/expect`

Called by BC immediately after sending `CMD_LIVESTREAM_ENABLE`. Arms the
timeout so a silent vehicle becomes `FAILED_TO_START` rather than sitting in
limbo.

```json
{"state": "STARTING", "room": "vehicle-01", "timeout_s": 25}
```

### `POST /{vid}/livestream/token`

One per viewer. Never contacts the vehicle.

Query parameters: `identity` (optional, one is generated if omitted),
`wait=true` to block until the stream comes up.

```json
{"url": "wss://live.bullworkmobility.com",
 "token": "eyJhbGci...",
 "room": "vehicle-01",
 "identity": "viewer-2a2a9f15f72f",
 "expires_in": 3600}
```

Returns `409` if the vehicle is not streaming.

**Identity must be unique per concurrent viewer.** Reusing one silently
disconnects the previous viewer.

### `GET /{vid}/livestream/state`

```json
{"state": "STREAMING", "room": "vehicle-01",
 "updated_at": 1789449217.2, "participant": "vehicle-vehicle-01"}
```

States: `STARTING`, `STREAMING`, `DISABLED`, `FAILED_TO_START`.

While streaming, the response also carries `viewers`, and `idle_since` once
the count reaches zero — that is the point from which the ten-minute idle
close is measured.

**A stream may be closed by the server at any time.** Ten minutes with no
viewers and it ends, whether or not anyone sent a stop command. Clients must
check this endpoint (or the event feed) before showing a stream rather than
assuming a link that worked earlier is still live; if the state is `DISABLED`,
start it again with the normal first-viewer flow.

### `GET /{vid}/livestream/events`

Server-sent events. One JSON object per state change, `: keepalive` every 15
seconds.

### `POST /system/webhooks/livekit`

LiveKit calls this. Not for BC. Authenticated by a signed JWT carrying a hash
of the body.

### `GET /healthz`

No auth. Returns the URLs the service is configured with — useful for
confirming a deployment picked up the right hostname.

---

## 5a. Installing on a shared machine

Defaults were chosen to avoid the common ones, but check before installing:

```bash
./deploy/check-ports.sh
```

It reports every TCP and UDP port the stack wants and what already holds it.
Any of them can be changed in `stack.env` except 443, which TURN needs so that
vehicles on restrictive mobile networks can connect.

## 6. Ports to open

| Port | Protocol | From | Purpose |
|---|---|---|---|
| 80 | TCP | anywhere | Certificate issuance only |
| 443 | TCP | anywhere | Viewers, vehicle publish, BC API |
| 3478 | UDP | anywhere | TURN |
| 5349 | TCP | anywhere | TURN over TLS |
| 7881 | TCP | anywhere | WebRTC TCP fallback |
| 8883 | TCP | vehicles, BC | MQTT over TLS |
| 50100-50200 | UDP | anywhere | Media to viewers |
| 7885-7895 | UDP | vehicles | WHIP ingest media |

The UDP ranges are the ones most often missed. Without them, signalling
succeeds and video silently never arrives.

---

## 7. Setup order

**Server, once:**

1. DNS A record → server IP
2. Caddy for TLS (`deploy/Caddyfile`)
3. `stack.env` — `HOST_IP`, `PUBLIC_HOST`, the three URLs, a fresh
   `LIVEKIT_API_SECRET` and `COMMANDER_API_TOKEN`
4. `./start.sh`
5. `sudo ./deploy/secure-mqtt.sh <host>`
6. `sudo ./deploy/secure-mqtt.sh <host> add-service bc` → give to BC

**Per vehicle, once:**

7. `sudo ./deploy/secure-mqtt.sh <host> add-vehicle vehicle-01`
8. `curl -X POST .../vehicle-01/livestream/provision`
9. Fill in `vehicle.env`: `VID`, MQTT credentials, `WHIP_URL`,
   `PUBLISH_TOKEN`, `TURN_SERVER`
10. `sudo systemctl enable --now vehicle-agent`

**To BC, once:**

- Stream API base URL
- `COMMANDER_API_TOKEN`
- MQTT host, port 8883, service credential
- The topic format and the two payloads
