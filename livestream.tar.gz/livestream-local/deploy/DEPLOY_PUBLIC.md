# Deploying to a public server

Same stack as the local rig, exposed properly. Do this on your own server
first; moving to GCP afterwards changes the hostname and nothing else.

Assumes a Linux server with a public IP and a DNS name pointing at it, for
example `live.example.com`.

---

## 1. DNS and firewall

One A record for the hostname, pointing at the server's public IP.

Open these:

| Port | Protocol | Why |
|---|---|---|
| 80 | TCP | Certificate issuance only. Nothing serves on it afterwards |
| 443 | TCP | Viewers (wss), vehicles (WHIP), BC (API) |
| 5349 | TCP | TURN over TLS |
| 3478 | UDP | TURN |
| 8883 | TCP | MQTT over TLS |
| 7881 | TCP | WebRTC TCP fallback |
| 50100-50200 | UDP | Media |
| 7885-7895 | UDP | WHIP ingest media |

The UDP ranges are the ones people forget. Miss them and signalling succeeds
while video silently never arrives — the hardest failure to diagnose.

---

## 2. TLS

```bash
sudo apt install caddy
sudo cp deploy/Caddyfile /etc/caddy/Caddyfile
sudo sed -i 's/live.example.com/live.yourdomain.com/' /etc/caddy/Caddyfile
sudo systemctl restart caddy
curl -I https://live.yourdomain.com     # a certificate should already be live
```

Caddy obtains and renews the certificate on its own. It must have port 80
reachable to do so.

---

## 3. Point the stack at the hostname

In `stack.env`:

```
HOST_IP=live.yourdomain.com
PUBLIC_HOST=live.yourdomain.com
LIVEKIT_WS_URL=wss://live.yourdomain.com
WHIP_BASE_URL=https://live.yourdomain.com/w
STREAM_API_URL=https://live.yourdomain.com/api
```

Then `./start.sh`. It picks up `PUBLIC_HOST` and renders the public LiveKit
config, which enables TURN and advertises the external address instead of the
internal one.

---

## 4. Secure MQTT

Do this before the broker is reachable from outside. Until it is done, anyone
who can reach the broker can publish teleop commands to a vehicle.

```bash
sudo ./deploy/secure-mqtt.sh live.yourdomain.com
sudo ./deploy/secure-mqtt.sh live.yourdomain.com add-service bc
sudo ./deploy/secure-mqtt.sh live.yourdomain.com add-vehicle vehicle-01
```

The service credential goes to BC and can command any vehicle. Each vehicle
credential can only read its own command topics and write its own status —
so a vehicle, or a SIM pulled out of one, cannot command any other vehicle.

---

## 5. Provision each vehicle

Once per vehicle, from anywhere that can reach the API:

```bash
curl -sX POST https://live.yourdomain.com/api/vehicle-01/livestream/provision \
  -H "Authorization: Bearer $COMMANDER_API_TOKEN" | jq .
```

Put the returned `whip_url` and `publish_token` into that vehicle's
`vehicle.env`, along with its MQTT credentials and:

```
MQTT_HOST=live.yourdomain.com
MQTT_PORT=8883
MQTT_TLS=true
TURN_SERVER=turns://live.yourdomain.com:5349
```

After this, BC's start command is a bare `CMD_LIVESTREAM_ENABLE` — the
vehicle already knows where to publish.

---

## 6. Verify

From the vehicle, before anything else:

```bash
curl -I https://live.yourdomain.com
mosquitto_sub -h live.yourdomain.com -p 8883 --capath /etc/ssl/certs \
  -u veh-vehicle-01 -P '<password>' -t 'vehicle-01/command/#' -v
```

Then the normal flow from wherever BC runs:

```bash
./test/flow.sh start vehicle-01
```

The one thing this deployment can prove that the LAN could not: whether a
vehicle on a mobile SIM connects at all. Watch the vehicle log for
`connection-state: connected`. If ICE fails there while it worked on the LAN,
TURN is doing the work, or failing to — check `turn` in the LiveKit log.

---

## A note on TURN and port 443

Caddy holds 443, so TURN runs on 5349. That works on most networks.

If it turns out your vehicles are on a carrier that only permits outbound
443, TURN needs 443 to itself. Two ways: give the server a second IP and
hostname for TURN alone, or move Caddy off 443 and let LiveKit terminate TLS
itself. Decide this only if testing on the real SIM shows 5349 being blocked
— don't pre-emptively complicate it.

---

## Moving to GCP afterwards

Copy the folder, point DNS at the new IP, keep the same `stack.env` with the
new hostname, rerun `secure-mqtt.sh` on the new box, and re-provision each
vehicle so it gets a WHIP URL on the new host. No application code changes on
either side.
