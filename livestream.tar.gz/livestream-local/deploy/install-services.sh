#!/usr/bin/env bash
# Install the stack as systemd services so it survives crashes and reboots.
#
# start.sh runs everything under nohup, which is fine on a bench but means a
# reboot or a crashed process stays down. Run this once on any machine the
# stack is meant to stay up on.
#
#   sudo ./deploy/install-services.sh
set -euo pipefail
cd "$(dirname "$0")/.."
ROOT=$(pwd)
RUN_USER=${SUDO_USER:-$USER}

[ -f stack.env ] || { echo "No stack.env — configure the stack first."; exit 1; }
set -a; . ./stack.env; set +a

echo "installing services for $RUN_USER from $ROOT"

# Render the configs once so the units do not depend on start.sh.
render() {
  python3 -c 'import os,sys,string
sys.stdout.write(string.Template(open(sys.argv[1]).read()).substitute(os.environ))' "$1" > "$2"
}
if [ -n "${PUBLIC_HOST:-}" ]; then
  render deploy/livekit-server.public.yaml.template livekit-server.yaml
else
  render livekit-server.yaml.template livekit-server.yaml
fi
render ingress.yaml.template ingress.yaml

# Containers: restart policy so Docker brings them back itself.
docker rm -f lk-redis lk-ingress >/dev/null 2>&1 || true
docker run -d --name lk-redis --network host --restart unless-stopped redis:7 \
  redis-server --port "$REDIS_PORT" >/dev/null
docker run -d --name lk-ingress --network host --restart unless-stopped \
  -v "$ROOT/ingress.yaml:/ingress.yaml:ro" livekit/ingress --config /ingress.yaml >/dev/null

cat > /etc/systemd/system/livekit-server.service <<EOF
[Unit]
Description=LiveKit SFU
After=network-online.target docker.service
Wants=network-online.target

[Service]
User=$RUN_USER
WorkingDirectory=$ROOT
ExecStart=$ROOT/bin/livekit-server --config $ROOT/livekit-server.yaml
Restart=always
RestartSec=3
LimitNOFILE=65535

[Install]
WantedBy=multi-user.target
EOF

cat > /etc/systemd/system/stream-api.service <<EOF
[Unit]
Description=Stream API (livestreaming control plane)
After=network-online.target livekit-server.service
Wants=network-online.target

[Service]
User=$RUN_USER
WorkingDirectory=$ROOT/commander
EnvironmentFile=$ROOT/stack.env
ExecStart=$ROOT/.venv/bin/uvicorn app:app --host 0.0.0.0 --port ${COMMANDER_PORT}
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

cat > /etc/systemd/system/stream-viewer.service <<EOF
[Unit]
Description=Test viewer page
After=network-online.target

[Service]
User=$RUN_USER
WorkingDirectory=$ROOT
ExecStart=/usr/bin/python3 -m http.server ${VIEWER_PORT} --bind 0.0.0.0
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable --now livekit-server stream-api stream-viewer
sleep 2

echo
for s in livekit-server stream-api stream-viewer mosquitto docker; do
  printf '%-18s %s\n' "$s" "$(systemctl is-active "$s" 2>/dev/null || echo inactive)"
done
docker ps --format '{{.Names}}	{{.Status}}'
echo
echo "Everything now restarts on crash and comes back after a reboot."
echo "Logs:  journalctl -u stream-api -f   /   docker logs -f lk-ingress"
echo "Do not use start.sh on this machine any more — it would start duplicates."
