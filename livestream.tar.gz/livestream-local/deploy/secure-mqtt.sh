#!/usr/bin/env bash
# Lock down MQTT before the broker is reachable from the internet.
#
# Until this is run, the broker is anonymous and unencrypted: anyone who can
# reach port 1883 can publish teleop commands to a vehicle. That is the most
# serious gap in the current setup, because there is a moving vehicle on the
# other end of that topic.
#
#   sudo ./deploy/secure-mqtt.sh live.example.com
#   sudo ./deploy/secure-mqtt.sh live.example.com add-vehicle vehicle-01
#   sudo ./deploy/secure-mqtt.sh live.example.com add-service bc
set -euo pipefail

HOSTNAME_ARG=${1:?usage: $0 <hostname> [add-vehicle <vid> | add-service <name>]}
ACTION=${2:-setup}
CERT_DIR="/var/lib/caddy/.local/share/caddy/certificates/acme-v02.api.letsencrypt.org-directory/${HOSTNAME_ARG}"
PW_FILE=/etc/mosquitto/passwd
ACL_FILE=/etc/mosquitto/acl

case "$ACTION" in
  setup)
    [ -f "${CERT_DIR}/${HOSTNAME_ARG}.crt" ] || {
      echo "No certificate at ${CERT_DIR}. Start Caddy first so it can issue one."
      exit 1; }

    # mosquitto runs as its own user and cannot read Caddy's store directly.
    install -d -o mosquitto -g mosquitto /etc/mosquitto/certs
    cp "${CERT_DIR}/${HOSTNAME_ARG}.crt" /etc/mosquitto/certs/server.crt
    cp "${CERT_DIR}/${HOSTNAME_ARG}.key" /etc/mosquitto/certs/server.key
    chown mosquitto:mosquitto /etc/mosquitto/certs/*
    chmod 640 /etc/mosquitto/certs/server.key

    touch "$PW_FILE" "$ACL_FILE"
    chown mosquitto:mosquitto "$PW_FILE" "$ACL_FILE"
    chmod 600 "$PW_FILE"

    cat > /etc/mosquitto/conf.d/secure.conf <<EOF
# Plain 1883 stays bound to loopback only — for local tooling on this host.
listener 1883 127.0.0.1
allow_anonymous false

# Everything from outside arrives over TLS.
listener 8883
certfile /etc/mosquitto/certs/server.crt
keyfile  /etc/mosquitto/certs/server.key
allow_anonymous false

password_file $PW_FILE
acl_file $ACL_FILE
EOF

    # Remove the wide-open dev listener if it is still present.
    rm -f /etc/mosquitto/conf.d/remote.conf
    sed -i 's/^allow_anonymous true/#allow_anonymous true/' \
      /etc/mosquitto/conf.d/default.conf 2>/dev/null || true

    systemctl restart mosquitto
    echo "MQTT now requires credentials. Add users with add-vehicle / add-service."
    ;;

  add-vehicle)
    VID=${3:?vid}
    USER="veh-${VID}"
    PASS=$(openssl rand -hex 16)
    mosquitto_passwd -b "$PW_FILE" "$USER" "$PASS"

    # A vehicle may only listen to its own commands and speak on its own
    # status topic. It cannot see or command any other vehicle.
    cat >> "$ACL_FILE" <<EOF

user $USER
topic read ${VID}/command/#
topic write ${VID}/status
EOF
    systemctl reload mosquitto || systemctl restart mosquitto
    echo "MQTT_USER=$USER"
    echo "MQTT_PASS=$PASS"
    echo "Put these in that vehicle's vehicle.env. This password is not stored anywhere else."
    ;;

  add-service)
    NAME=${3:?name}
    PASS=$(openssl rand -hex 24)
    mosquitto_passwd -b "$PW_FILE" "$NAME" "$PASS"
    cat >> "$ACL_FILE" <<EOF

user $NAME
topic write +/command/#
topic read +/status
EOF
    systemctl reload mosquitto || systemctl restart mosquitto
    echo "MQTT_USER=$NAME"
    echo "MQTT_PASS=$PASS"
    echo "Give these to BC. It can command any vehicle, so treat it as a high-value secret."
    ;;

  *) echo "unknown action: $ACTION"; exit 1 ;;
esac
