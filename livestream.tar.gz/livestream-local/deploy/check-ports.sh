#!/usr/bin/env bash
# Run before installing on a shared machine. Every port the stack needs, and
# whether something already has it.
set -uo pipefail
cd "$(dirname "$0")/.."
[ -f stack.env ] && { set -a; . ./stack.env; set +a; }

check() {
  local port=$1 proto=$2 what=$3
  local flag="-ln${proto:0:1}"
  if sudo ss "$flag" 2>/dev/null | grep -qE "[:.]${port}\b"; then
    printf '  TAKEN  %-6s %-5s %s\n' "$port" "$proto" "$what"
    sudo ss -ln"${proto:0:1}"p 2>/dev/null | grep -E "[:.]${port}\b" | \
      sed 's/^/           /' | head -1
    return 1
  fi
  printf '  free   %-6s %-5s %s\n' "$port" "$proto" "$what"
}

fail=0
echo "TCP:"
check "${LIVEKIT_PORT:-7880}"     tcp "LiveKit signalling"       || fail=1
check "${LIVEKIT_TCP_PORT:-7881}" tcp "WebRTC TCP fallback"      || fail=1
check "${WHIP_PORT:-8070}"        tcp "WHIP ingest"              || fail=1
check "${COMMANDER_PORT:-8095}"   tcp "Stream API"               || fail=1
check "${VIEWER_PORT:-8081}"      tcp "viewer page"              || fail=1
check "${REDIS_PORT:-6380}"       tcp "our Redis"                || fail=1

echo "UDP (media — these are the ones people forget):"
check "${LIVEKIT_UDP_START:-50100}" udp "LiveKit media range start" || fail=1
check "${WHIP_UDP_START:-7885}"     udp "WHIP ingest media start"   || fail=1
check 3478                          udp "TURN"                      || fail=1

echo
if [ "$fail" = 0 ]; then
  echo "All clear."
else
  echo "Change the conflicting ports in stack.env before starting."
  echo "Nothing here needs a specific port except 443 for TURN."
fi
exit $fail
