# Fleet Livestreaming — Architecture and Security Assessment

**Version:** 1.0 — post-PoC
**Date:** 15 September 2026
**Status:** Design validated end to end on a local rig. Not deployed. Not hardened.

---

## 1. Scope and naming

Livestreaming is a **standalone service**, not a module inside Bullwork
Commander. It owns the media plane and the credentials for it. Bullwork
Commander owns users, permissions and fleet logic, and talks to this service
over one HTTP API.

Three names that have been used interchangeably and should not be:

| Name in this doc | What it is | Where it runs |
|---|---|---|
| **BC** (Bullwork Commander) | The existing brain — users, auth, dashboards, fleet logic | Existing infrastructure |
| **Stream Control API** | This project's control plane. Mints credentials, wakes vehicles, tracks state. Never touches video. In the PoC repo this is `commander/app.py` | GCP VM |
| **LiveKit** | The media server — SFU, WHIP ingress, TURN | Same GCP VM |

The earlier design docs called the Stream Control API "NEXUS-COMMANDER",
which collides with Bullwork Commander. Renaming it is recommended before
this reaches a wider audience.

---

## 2. Block diagram

```mermaid
flowchart TB
    subgraph VEHICLE["Vehicle — Jetson Orin + ZED 2i"]
        ZED["ZED 2i camera"]
        ENC["Hardware H264 encode<br/>nvv4l2h264enc"]
        AGENT["Vehicle agent<br/>WHIP client + MQTT subscriber"]
        ZED --> ENC --> AGENT
    end

    subgraph GCP["GCP VM — single node"]
        PROXY["Reverse proxy<br/>TLS termination :443"]
        INGRESS["LiveKit Ingress<br/>WHIP terminator"]
        SFU["LiveKit SFU<br/>fanout + TURN"]
        API["Stream Control API<br/>tokens, state, MQTT publish"]
        REDIS[("Redis<br/>stream state")]
        MQTT["MQTT broker"]
        PROXY --> INGRESS
        PROXY --> SFU
        PROXY --> API
        INGRESS -->|"RTP"| SFU
        SFU -->|"webhook"| API
        API --> REDIS
        API -->|"publish"| MQTT
    end

    subgraph CONSUMERS["Consumers"]
        BC["Bullwork Commander<br/>users, permissions, audit"]
        USER["Operator browser<br/>or app"]
    end

    AGENT -->|"1 - WHIP publish, one stream"| PROXY
    MQTT -->|"2 - CMD_LIVESTREAM_ENABLE"| AGENT
    BC -->|"3 - HTTPS - request token"| PROXY
    BC -->|"4 - hands token to user"| USER
    USER -->|"5 - WebRTC subscribe, direct"| PROXY
```

Three properties this layout is built around:

**The vehicle encodes and sends once.** N viewers do not multiply the
vehicle's uplink. The SFU does fanout using GCP's bandwidth, not the
vehicle's cellular link. This was verified — two concurrent viewers produced
no change in the vehicle's publish.

**The control plane never carries video.** The Stream Control API decides who
may watch and mints credentials; media goes browser-to-LiveKit directly. The
API cannot become a bandwidth bottleneck.

**The vehicle only makes outbound connections.** It needs no public address,
no inbound firewall rule, and no port forwarding. This is why a vehicle on an
M2M SIM behind carrier NAT can work at all.

---

## 3. Data flow

### 3.1 Cold start — first viewer, vehicle idle

```mermaid
sequenceDiagram
    participant U as Operator
    participant BC as Bullwork Commander
    participant API as Stream Control API
    participant LK as LiveKit
    participant MQ as MQTT broker
    participant V as Vehicle agent

    U->>BC: open camera for vehicle-01
    BC->>BC: authenticate user, check permission
    BC->>API: POST /{vid}/livestream
    API->>API: check Redis - not streaming
    API->>LK: create WHIP ingress for room pid:vid
    LK-->>API: stream key
    API->>MQ: CMD_LIVESTREAM_ENABLE with whip_url + token
    MQ->>V: deliver command
    V->>V: start pipeline, gather ICE
    V->>LK: POST SDP offer to whip_url
    LK-->>V: 201 + SDP answer + Location
    V->>LK: RTP media
    LK->>API: webhook track_published
    API->>API: Redis state = STREAMING
    API-->>BC: url + viewer token
    BC-->>U: stream link
    U->>LK: WebRTC subscribe
```

If no `track_published` webhook arrives within the timeout, the API fires
`CMD_LIVESTREAM_DISABLE` and records `FAILED_TO_START` rather than leaving a
phantom STREAMING state.

### 3.2 Warm join — stream already running

This is the case that matters most operationally, because it is every viewer
after the first.

```mermaid
sequenceDiagram
    participant U as Second operator
    participant BC as Bullwork Commander
    participant API as Stream Control API
    participant LK as LiveKit

    U->>BC: open camera for vehicle-01
    BC->>BC: authenticate user, check permission
    BC->>API: POST /{vid}/livestream/token
    API->>API: Redis says STREAMING
    API->>API: mint token, unique identity
    API-->>BC: url + viewer token
    BC-->>U: stream link
    U->>LK: WebRTC subscribe
```

**No MQTT. No vehicle involvement. No renegotiation.** The vehicle does not
know how many people are watching and does not care. Verified in testing —
the broker stayed silent while a second viewer joined.

### 3.3 Teardown

`DELETE /{vid}/livestream` publishes `CMD_LIVESTREAM_DISABLE`; the
vehicle issues a WHIP `DELETE` and stops; LiveKit fires `room_finished`; the
API clears Redis and emits an SSE `DISABLED` event.

---

## 4. Interface contract with Bullwork Commander

BC uses HTTP only. It never publishes MQTT, never talks to LiveKit, and never
holds a LiveKit secret.

| Endpoint | Purpose | Touches vehicle |
|---|---|---|
| `POST /{vid}/livestream` | Wake the vehicle and begin publishing | Yes — MQTT |
| `POST /{vid}/livestream/token` | Per-viewer credentials | No |
| `DELETE /{vid}/livestream` | Stop publishing | Yes — MQTT |
| `GET /{vid}/livestream/state` | Is it live | No |
| `GET /{vid}/livestream/events` | SSE state changes | No |

**MQTT is used once, at the start. The API serves everyone after.** That is
the core of the design: waking a vehicle is a command; watching it is a
lookup.

Two rules BC must honour:

1. **Viewer identity must be unique per concurrent session.** LiveKit permits
   one connection per identity per room; a second connection on the same
   identity silently disconnects the first. The API generates a random
   identity per call, so BC should request one token per viewer rather than
   reusing one.
2. **Tokens are short-lived** (1 hour by default). Long sessions need a
   refresh path.

---

## 5. Trust boundaries

```mermaid
flowchart LR
    subgraph T1["Trusted — holds secrets"]
        API2["Stream Control API<br/>holds LiveKit API secret<br/>holds MQTT credentials"]
    end
    subgraph T2["Semi-trusted — service caller"]
        BC2["Bullwork Commander<br/>holds service token only"]
    end
    subgraph T3["Untrusted — receives scoped grant"]
        USER2["Operator browser<br/>holds one viewer token:<br/>one room, subscribe only, 1h"]
    end
    subgraph T4["Semi-trusted — fleet device"]
        VEH["Vehicle<br/>holds its own MQTT credential<br/>and a per-session publish token"]
    end

    BC2 -->|"service token"| API2
    API2 -->|"viewer token, scoped"| BC2
    BC2 --> USER2
    API2 -->|"publish token via MQTT"| VEH
```

The critical property: **the LiveKit API secret never leaves the Stream
Control API.** Anyone holding it can mint a token for any room in the fleet.
BC receives only minted, room-scoped, subscribe-only tokens. If BC is
compromised, the attacker gets what BC's users could already see, not the
whole fleet's cameras.

Room isolation is enforced by LiveKit itself, not by convention. A token for
`vehicle-01` cannot subscribe to `vehicle-02`.

---

## 6. Security assessment

### 6.1 What is genuinely sound

| Control | Status |
|---|---|
| Room isolation between vehicles | Enforced by LiveKit, not by application code |
| Viewer token scope | One room, `canPublish: false`, `canSubscribe: true`, 1h TTL — verified by decoding issued tokens |
| Webhook authenticity | JWT signed with the API secret, carrying a SHA-256 of the body; both signature and body integrity checked. Forged webhooks rejected |
| Secret containment | LiveKit API secret held by one service, never sent to BC or the browser |
| Vehicle attack surface | Outbound-only. No listening ports, no inbound rules |
| State truthfulness | `STREAMING` set only on a real `track_published` webhook, never on the MQTT send |
| Failure handling | Watchdog converts a silent vehicle into `FAILED_TO_START` plus an automatic disable |

### 6.2 What is not — current PoC configuration

Everything below is a deliberate dev-grade choice from the PoC, and every one
of them is unacceptable on a public network.

| # | Gap | Consequence | Severity |
|---|---|---|---|
| 1 | MQTT anonymous and unencrypted | **Anyone who can reach the broker can publish teleop commands and drive a vehicle.** No authentication of any kind | **Critical — physical safety** |
| 2 | No TLS anywhere | Publish tokens, viewer tokens and the service token all cross the network in clear text. Capture enables stream injection — a fake camera feed shown to an operator | **Critical** |
| 3 | Single shared service bearer token | Whoever holds it can start, stop and view every vehicle in every fleet. No per-vehicle authorization | **High** |
| 4 | `pid` / `vid` not validated | Values flow from the URL path into MQTT topics and Redis keys. A `vid` containing `/`, `+` or `#` can publish onto unintended topics | **High** |
| 5 | Publish token never expires | It is the ingress stream key. Anyone who captures it can publish into that vehicle's room indefinitely | **Medium** |
| 6 | SSE endpoint unauthenticated | Leaks per-vehicle streaming state to anyone | **Medium** |
| 7 | No reconciliation loop | Redis changes only on webhooks. A dropped webhook leaves a phantom `STREAMING` that nothing will ever correct | **Medium — availability** |
| 8 | No room cap or rate limiting | Uncapped concurrent streams; bandwidth is the ceiling. One caller can exhaust egress and degrade every stream at once, with an unbounded bill | **Medium — cost and availability** |
| 9 | Process-local watchdog state | More than one API worker, or a restart, loses in-flight watchdogs. Vehicles can stick in `STARTING` | **Low** |
| 10 | No audit trail in this service | Requests are indistinguishable from one another. Camera-access accountability lives entirely in BC's logs | **Accepted** — BC owns this by agreement |

### 6.3 Untested, not merely unhardened

| Item | Why it cannot be judged from the PoC |
|---|---|
| **TURN over carrier NAT** | Every test so far ran on a LAN and a USB link with no real NAT. On M2M SIMs, carrier NAT can prevent a connection outright — a binary failure, not degradation. This is the single largest unknown |
| **Cellular uplink capacity** | The vehicle publishes a fixed 3 Mbps. Many M2M plans cannot sustain that on uplink, and it varies with signal and motion. The publisher does not currently adapt |
| **Sustained multi-vehicle load** | Tested with one vehicle and two viewers |

---

## 7. Verdict: is this valid?

**As an architecture — yes.** The design is correct and validated end to end.
Encode-once-fan-out-many, a control plane that never touches media,
webhook-driven state rather than trusting a fire-and-forget command, and room
isolation enforced by the media server are the right choices and do not need
revisiting. Nothing in the PoC suggests a structural problem.

**As a deployment — no, not yet.** The current configuration is explicitly
dev-grade. Item 1 alone — anonymous MQTT carrying teleop — means a vehicle
with wheels must not be attached to this setup on any network where untrusted
parties can reach the broker.

The distinction matters: the work remaining is configuration and hardening,
not redesign.

### Gating items before any vehicle on a real SIM depends on this

1. **MQTT authentication and TLS** — per-vehicle credentials, topic ACLs
   scoped to that vehicle's own `vid`, port 8883, `allow_anonymous false`.
   First because teleop rides on it.
2. **TLS everywhere** — real certificate on a real domain. Also a
   prerequisite for TURN.
3. **TURN enabled and tested against the actual M2M SIM** — this determines
   whether vehicles connect at all.
4. **Input validation** on `pid` and `vid` — roughly ten lines.
5. **Per-caller authorization** in the Stream Control API, if it will ever
   serve more than one tenant.
6. **Reconciliation loop** — periodic sync of Redis against LiveKit's actual
   room state, so dropped webhooks self-heal.
7. **Fleet-wide concurrent room cap** — bounds both egress cost and failure
   blast radius.

---

## 8. Validated evidence

Measured on the PoC rig, not estimated.

| Property | Result |
|---|---|
| Video source | ZED 2i, left eye, cropped from 2560x720 side-by-side |
| Encode | `nvv4l2h264enc` — Jetson hardware encoder confirmed in use |
| Delivered stream | 1280x720 at 30 fps, ~2770 kbps |
| Receiver jitter buffer | 8 ms |
| Cold start | MQTT command to `STREAMING` webhook in roughly 10 s, dominated by pipeline start |
| Warm join | Token minted with zero MQTT traffic and no vehicle-side change |
| Multi-viewer | Two concurrent viewers, no effect on the publisher |
| Failure path | Watchdog produced `FAILED_TO_START` and an automatic disable |
| Webhook forgery | Rejected |

Packet loss observed on one viewer was traced to the office Wi-Fi hop between
the server and that device, not to the pipeline. A viewer on the server
machine itself showed no loss.

---

## 9. Deployment target

Single GCP Compute Engine VM, `n2-standard-4`, static external IP,
`live.<company-domain>` and `mqtt.<company-domain>` pointing at it.

Runs: LiveKit SFU, LiveKit WHIP ingress, Redis, Stream Control API, MQTT
broker, reverse proxy for TLS.

Firewall: TCP 443 and 80 (certificate issuance), TCP 7881 (RTC TCP
fallback), TCP 8883 (MQTT over TLS), UDP 50100-60000 (media), UDP 3478 and
51000-51050 (TURN).

The move from the PoC rig changes configuration values only — no application
code changes on either the server or the vehicle. The vehicle learns its new
endpoint from the `whip_url` inside the MQTT payload, so only the broker
address is configured on the Jetson.

Bandwidth, not CPU, is the scaling ceiling. Budget egress accordingly and cap
concurrent rooms.
