#!/usr/bin/env bash
# One-time setup. Run once per laptop, then use start.sh / stop.sh.
set -euo pipefail
cd "$(dirname "$0")"

LIVEKIT_VER=1.13.5
LK_CLI_VER=2.18.2

echo "== 1/5 apt packages =="
sudo apt-get update -qq
sudo apt-get install -y docker.io mosquitto mosquitto-clients python3-venv curl jq
sudo systemctl enable --now docker
if ! groups "$USER" | grep -qw docker; then
  sudo usermod -aG docker "$USER"
  echo "!! Added $USER to the docker group. Log out and back in (or run 'newgrp docker'),"
  echo "!! then re-run this script."
  exit 1
fi

echo "== 2/5 livekit binaries =="
mkdir -p bin
if [ ! -x bin/livekit-server ]; then
  curl -sSL -o /tmp/livekit.tgz \
    "https://github.com/livekit/livekit-server/releases/download/v${LIVEKIT_VER}/livekit_${LIVEKIT_VER}_linux_amd64.tar.gz"
  tar xzf /tmp/livekit.tgz -C bin livekit-server
fi
if [ ! -x bin/lk ]; then
  curl -sSL -o /tmp/lk.tgz \
    "https://github.com/livekit/livekit-cli/releases/download/v${LK_CLI_VER}/lk_${LK_CLI_VER}_linux_amd64.tar.gz"
  tar xzf /tmp/lk.tgz -C bin lk
fi
./bin/livekit-server --version && ./bin/lk --version

echo "== 3/5 docker images (ingress has no prebuilt binary) =="
docker pull livekit/ingress:latest
docker pull redis:7

echo "== 4/5 mosquitto listening on all interfaces (dev only) =="
sudo tee /etc/mosquitto/conf.d/remote.conf >/dev/null <<'EOF'
listener 1883 0.0.0.0
allow_anonymous true
EOF
sudo systemctl enable --now mosquitto
sudo systemctl restart mosquitto

echo "== 5/5 commander venv =="
python3 -m venv .venv
./.venv/bin/pip install -q --upgrade pip
./.venv/bin/pip install -q -r commander/requirements.txt
./.venv/bin/pip install -q fakeredis httpx    # for test/commander_selftest.py

if [ ! -f stack.env ]; then
  cp stack.env.example stack.env
  sed -i "s/^LIVEKIT_API_SECRET=.*/LIVEKIT_API_SECRET=$(openssl rand -hex 24)/" stack.env
  IP=$(ip -4 route get 1.1.1.1 2>/dev/null | awk '{print $7; exit}')
  [ -n "$IP" ] && sed -i "s/^HOST_IP=.*/HOST_IP=${IP}/" stack.env
  echo
  echo "Created stack.env with HOST_IP=${IP:-<unset>} and a fresh secret."
  echo "Check that HOST_IP is the address the Jetson can reach, then: ./start.sh"
else
  echo "stack.env already exists — left untouched."
fi
