#!/usr/bin/env bash
# Render configs from stack.env and start the whole stack detached.
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p logs run

[ -f stack.env ] || { echo "No stack.env — run ./setup.sh first (or cp stack.env.example stack.env)"; exit 1; }
set -a; . ./stack.env; set +a

case "$HOST_IP" in
  127.0.0.1|localhost|"")
    echo "HOST_IP is '$HOST_IP'. The Jetson cannot reach that. Set a real address in stack.env."
    exit 1;;
esac
echo "HOST_IP=$HOST_IP"

# ---- render templates ----------------------------------------------------
# string.Template rather than envsubst: one less package to have installed.
render() {
  python3 -c 'import os,sys,string
sys.stdout.write(string.Template(open(sys.argv[1]).read()).substitute(os.environ))' "$1" > "$2"
}
if [ -n "${PUBLIC_HOST:-}" ]; then
  echo "public mode : $PUBLIC_HOST (TURN enabled, external IP advertised)"
  render deploy/livekit-server.public.yaml.template livekit-server.yaml
else
  render livekit-server.yaml.template livekit-server.yaml
fi
render ingress.yaml.template        ingress.yaml

# ---- redis ---------------------------------------------------------------
docker start lk-redis >/dev/null 2>&1 || \
  docker run -d --name lk-redis --network host redis:7 \
    redis-server --port "$REDIS_PORT" >/dev/null
echo "redis        : up (localhost:$REDIS_PORT)"

# ---- livekit-server ------------------------------------------------------
if ! pgrep -f "livekit-server --config" >/dev/null; then
  nohup ./bin/livekit-server --config livekit-server.yaml > logs/livekit-server.log 2>&1 &
  disown
fi
echo "livekit      : ws://$HOST_IP:$LIVEKIT_PORT"

# ---- whip ingress --------------------------------------------------------
docker rm -f lk-ingress >/dev/null 2>&1 || true
docker run -d --name lk-ingress --network host \
  -v "$(pwd)/ingress.yaml:/ingress.yaml:ro" \
  livekit/ingress --config /ingress.yaml >/dev/null
echo "whip ingress : http://$HOST_IP:$WHIP_PORT/w/<stream_key>"

# ---- mosquitto -----------------------------------------------------------
sudo systemctl is-active --quiet mosquitto || sudo systemctl start mosquitto
echo "mqtt         : $HOST_IP:$MQTT_PORT"

# ---- commander -----------------------------------------------------------
pkill -f "uvicorn app:app" 2>/dev/null || true
( cd commander && nohup ../.venv/bin/uvicorn app:app \
    --host 0.0.0.0 --port "$COMMANDER_PORT" > ../logs/commander.log 2>&1 & disown )
echo "commander    : http://$HOST_IP:$COMMANDER_PORT"

# ---- viewer page ---------------------------------------------------------
pkill -f "http.server $VIEWER_PORT" 2>/dev/null || true
nohup python3 -m http.server "$VIEWER_PORT" --bind 0.0.0.0 > logs/viewer.log 2>&1 &
disown
echo "viewer       : http://$HOST_IP:$VIEWER_PORT/viewer.html"

sleep 2
echo
echo "health:"
curl -s "http://localhost:$COMMANDER_PORT/healthz" | jq . || echo "  commander not answering yet — check logs/commander.log"
echo
echo "Watch logs with:  tail -f logs/*.log   and   docker logs -f lk-ingress"
