#!/usr/bin/env bash
# Stop everything start.sh launched. Leaves mosquitto (a system service) alone.
set -uo pipefail
cd "$(dirname "$0")"
[ -f stack.env ] && { set -a; . ./stack.env; set +a; }

pkill -f "uvicorn app:app"            && echo "commander    : stopped"
pkill -f "livekit-server --config"    && echo "livekit      : stopped"
pkill -f "http.server ${VIEWER_PORT:-8081}" && echo "viewer       : stopped"
docker rm -f lk-ingress >/dev/null 2>&1 && echo "whip ingress : stopped"
docker stop lk-redis    >/dev/null 2>&1 && echo "redis        : stopped"

# Leftover processes are a real source of phantom CPU load and stuck UDP
# ports — check nothing survived.
echo
echo "still running (should be empty):"
pgrep -af "livekit-server|uvicorn app:app|http.server" || echo "  nothing"
