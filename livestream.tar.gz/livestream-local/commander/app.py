"""
Stream API — the livestreaming control plane.

Division of responsibility (per HOW_IT_WORKS.md):

  Bullwork Commander  owns users, permissions, and the MQTT command channel.
                      It sends CMD_LIVESTREAM_ENABLE / DISABLE to vehicles.
  This service        owns LiveKit: provisions each vehicle's publish endpoint,
                      tracks which vehicles are live, mints viewer passes.
                      It does NOT talk to vehicles and does NOT publish MQTT.
  LiveKit             carries the video.

Endpoints BC uses:

  POST   /{vid}/livestream/provision   once per vehicle — get its publish URL
  POST   /{vid}/livestream/expect      after sending the MQTT start command
  POST   /{vid}/livestream/token       per viewer — a scoped viewing pass
  GET    /{vid}/livestream/state       is it live
  GET    /{vid}/livestream/events      SSE state changes
  POST   /system/webhooks/livekit            LiveKit calls this, not BC
  GET    /healthz

Config comes from the environment (stack.env).
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import secrets
import time
from contextlib import asynccontextmanager
from datetime import timedelta
from typing import Any, Dict, Optional, Set

import redis.asyncio as aioredis
from fastapi import Depends, FastAPI, Header, HTTPException, Request
from fastapi.responses import JSONResponse, StreamingResponse
from livekit import api

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s %(levelname)-5s %(name)s: %(message)s")
log = logging.getLogger("streamapi")

# --------------------------------------------------------------------------
# config
# --------------------------------------------------------------------------

HOST = os.environ.get("HOST_IP", "127.0.0.1")
LIVEKIT_PORT = os.environ.get("LIVEKIT_PORT", "7880")
LIVEKIT_HTTP_URL = os.environ.get("LIVEKIT_HTTP_URL", f"http://{HOST}:{LIVEKIT_PORT}")
# What viewers are told to connect to. wss:// once TLS is in front.
LIVEKIT_WS_URL = os.environ.get("LIVEKIT_WS_URL", f"ws://{HOST}:{LIVEKIT_PORT}")
LIVEKIT_API_KEY = os.environ["LIVEKIT_API_KEY"]
LIVEKIT_API_SECRET = os.environ["LIVEKIT_API_SECRET"]
WHIP_BASE_URL = os.environ.get(
    "WHIP_BASE_URL", f"http://{HOST}:{os.environ.get('WHIP_PORT', '8080')}/w")

REDIS_URL = os.environ.get("REDIS_URL", "redis://localhost:6380/1")
API_TOKEN = os.environ.get("COMMANDER_API_TOKEN", "dev-operator-token")
PUBLISH_TIMEOUT_S = float(os.environ.get("PUBLISH_TIMEOUT_S", "25"))
VIEWER_TOKEN_TTL_S = int(os.environ.get("VIEWER_TOKEN_TTL_S", "3600"))
RECONCILE_EVERY_S = float(os.environ.get("RECONCILE_EVERY_S", "30"))
# A stream nobody is watching is closed from the server after this long. Clients
# cannot be relied on to stop what they started — a closed laptop or a crashed
# tab must not leave a vehicle publishing all day.
IDLE_CLOSE_S = float(os.environ.get("IDLE_CLOSE_S", "600"))

STATE_STARTING = "STARTING"
STATE_STREAMING = "STREAMING"
STATE_DISABLED = "DISABLED"
STATE_FAILED = "FAILED_TO_START"

# The vid lands in Redis keys and room names. Anything outside this set is
# rejected rather than sanitised, so a malformed id can never reach LiveKit.
ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")


def check_id(vid: str) -> None:
    if not ID_RE.match(vid):
        raise HTTPException(400, "vid must be 1-64 chars of [A-Za-z0-9_-]")


def room_name(vid: str) -> str:
    """Vehicle ids are unique fleet-wide, so the vid alone names the room."""
    return vid


def state_key(vid: str) -> str:
    return f"vehicle:livestream:{vid}"


# --------------------------------------------------------------------------
# process state
# --------------------------------------------------------------------------

redis: aioredis.Redis
watchdogs: Dict[str, asyncio.Task] = {}
subscribers: Dict[str, Set[asyncio.Queue]] = {}


def lk_client() -> api.LiveKitAPI:
    return api.LiveKitAPI(LIVEKIT_HTTP_URL, LIVEKIT_API_KEY, LIVEKIT_API_SECRET)


@asynccontextmanager
async def lifespan(app: FastAPI):
    global redis
    redis = aioredis.from_url(REDIS_URL, decode_responses=True)
    reconciler = asyncio.create_task(reconcile_loop())
    log.info("stream api up — livekit=%s whip_base=%s viewer_url=%s",
             LIVEKIT_HTTP_URL, WHIP_BASE_URL, LIVEKIT_WS_URL)
    yield
    reconciler.cancel()
    for t in watchdogs.values():
        t.cancel()
    await redis.aclose()


app = FastAPI(title="Stream API", lifespan=lifespan)


def require_auth(authorization: Optional[str] = Header(None)) -> None:
    """Service-level auth. BC holds this token; it is not a user credential."""
    if authorization != f"Bearer {API_TOKEN}":
        raise HTTPException(401, "missing or bad Authorization bearer token")


# --------------------------------------------------------------------------
# state + SSE
# --------------------------------------------------------------------------

async def read_state(vid: str) -> Dict[str, Any]:
    raw = await redis.get(state_key(vid))
    if not raw:
        return {"state": STATE_DISABLED}
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return {"state": raw}


async def write_state(vid: str, state: str, **extra: Any) -> Dict[str, Any]:
    doc = {"state": state, "room": room_name(vid),
           "updated_at": time.time(), **extra}
    if state == STATE_DISABLED:
        await redis.delete(state_key(vid))
    else:
        await redis.set(state_key(vid), json.dumps(doc), ex=6 * 3600)
    await emit(vid, doc)
    return doc


async def emit(vid: str, doc: Dict[str, Any]) -> None:
    payload = {"event": "vehicle_livestream", "vid": vid, **doc}
    log.info("state %s -> %s", vid, doc.get("state"))
    for q in list(subscribers.get(room_name(vid), ())):
        q.put_nowait(payload)


# --------------------------------------------------------------------------
# LiveKit
# --------------------------------------------------------------------------

async def ensure_ingress(vid: str):
    """One persistent WHIP ingress per vehicle. Reused, never duplicated."""
    room = room_name(vid)
    lk = lk_client()
    try:
        existing = await lk.ingress.list_ingress(api.ListIngressRequest(room_name=room))
        for info in existing.items:
            if info.input_type == api.IngressInput.WHIP_INPUT and info.stream_key:
                return info
        info = await lk.ingress.create_ingress(
            api.CreateIngressRequest(
                input_type=api.IngressInput.WHIP_INPUT,
                name=f"whip-{vid}",
                room_name=room,
                participant_identity=f"vehicle-{vid}",
                participant_name=f"Vehicle {vid}",
                enable_transcoding=False,   # WHIP is pass-through only
            )
        )
        log.info("created ingress %s for %s", info.ingress_id, room)
        return info
    finally:
        await lk.aclose()


def mint_viewer_token(vid: str, identity: str) -> str:
    grants = api.VideoGrants(
        room_join=True,
        room=room_name(vid),
        can_subscribe=True,
        can_publish=False,
        can_publish_data=False,
    )
    return (
        api.AccessToken(LIVEKIT_API_KEY, LIVEKIT_API_SECRET)
        .with_identity(identity)
        .with_name(identity)
        .with_grants(grants)
        .with_ttl(timedelta(seconds=VIEWER_TOKEN_TTL_S))
        .to_jwt()
    )


# --------------------------------------------------------------------------
# watchdog + reconciliation
# --------------------------------------------------------------------------

async def arm_watchdog(vid: str) -> None:
    """No video within the window means the vehicle never came up. We record
    the failure; BC owns the command channel and issues any stop command."""
    room = room_name(vid)
    old = watchdogs.pop(room, None)
    if old:
        old.cancel()

    async def run() -> None:
        try:
            await asyncio.sleep(PUBLISH_TIMEOUT_S)
            cur = await read_state(vid)
            if cur.get("state") == STATE_STREAMING:
                return
            log.warning("no publish within %ss for %s", PUBLISH_TIMEOUT_S, room)
            await write_state(vid, STATE_FAILED,
                              reason=f"no video within {PUBLISH_TIMEOUT_S}s")
        except asyncio.CancelledError:
            pass
        finally:
            watchdogs.pop(room, None)

    watchdogs[room] = asyncio.create_task(run())


async def close_idle(vid: str, reason: str) -> None:
    """End a stream from the server side. Deleting the room disconnects the
    vehicle's publish session, so the vehicle stops sending without any client
    or BC having to act. The ingress object survives and is reused next time."""
    try:
        lk = lk_client()
        try:
            await lk.room.delete_room(api.DeleteRoomRequest(room=room_name(vid)))
        finally:
            await lk.aclose()
        log.warning("closed idle stream %s: %s", vid, reason)
        await write_state(vid, STATE_DISABLED, reason=reason, closed_by="server")
    except Exception as exc:  # noqa: BLE001
        log.error("could not close idle stream %s: %s", vid, exc)


async def reconcile_loop() -> None:
    """Webhooks can be dropped. Periodically compare Redis against what LiveKit
    actually has, so a missed webhook self-heals instead of leaving a vehicle
    stuck in a state that is no longer true.

    This is also where unwatched streams get closed. A client that never calls
    stop — a closed laptop, a crashed tab, an operator who walked away — must
    not be able to leave a vehicle publishing indefinitely, so the decision is
    made here from LiveKit's own participant counts rather than trusting
    anyone to tell us."""
    await asyncio.sleep(5)
    while True:
        try:
            lk = lk_client()
            try:
                rooms = await lk.room.list_rooms(api.ListRoomsRequest())
            finally:
                await lk.aclose()
            live = {r.name: r for r in rooms.rooms if r.num_publishers > 0}

            async for key in redis.scan_iter(match="vehicle:livestream:*"):
                vid = key.split("vehicle:livestream:", 1)[1]
                cur = await read_state(vid)
                room = room_name(vid)
                if cur.get("state") == STATE_STREAMING and room not in live:
                    log.warning("reconcile: %s marked STREAMING but is not — clearing", room)
                    await write_state(vid, STATE_DISABLED, reason="reconciled")

            for room, info in live.items():
                vid = room
                if not ID_RE.match(vid):
                    continue          # not one of ours
                cur = await read_state(vid)
                if cur.get("state") != STATE_STREAMING:
                    log.warning("reconcile: %s is live but was %s — correcting",
                                room, cur.get("state"))
                    cur = await write_state(vid, STATE_STREAMING, reason="reconciled")

                # Subscribers are participants that are not the publisher.
                viewers = max(0, info.num_participants - info.num_publishers)
                if viewers > 0:
                    # write_state replaces the document, so idle_since is
                    # dropped simply by not passing it again.
                    if cur.get("idle_since") or cur.get("viewers") != viewers:
                        await write_state(vid, STATE_STREAMING, viewers=viewers)
                    continue

                idle_since = cur.get("idle_since") or time.time()
                idle_for = time.time() - idle_since
                if idle_for >= IDLE_CLOSE_S:
                    await close_idle(
                        vid, f"no viewers for {int(idle_for // 60)} minutes")
                else:
                    if not cur.get("idle_since"):
                        log.info("%s has no viewers — closing in %.0f min unless "
                                 "someone joins", vid, IDLE_CLOSE_S / 60)
                    await write_state(vid, STATE_STREAMING, viewers=0,
                                      idle_since=idle_since)
        except asyncio.CancelledError:
            return
        except Exception as exc:  # noqa: BLE001
            log.warning("reconcile failed: %s", exc)
        await asyncio.sleep(RECONCILE_EVERY_S)


# --------------------------------------------------------------------------
# BC-facing API
# --------------------------------------------------------------------------

@app.post("/{vid}/livestream/provision", dependencies=[Depends(require_auth)])
async def provision(vid: str):
    """
    Called once per vehicle, at setup.

    Returns the publish URL and credential for that vehicle. Put these into the
    vehicle's config (WHIP_URL / PUBLISH_TOKEN in vehicle.env) so BC's start
    command needs no payload. Idempotent — repeated calls return the same
    values.
    """
    check_id(vid)
    info = await ensure_ingress(vid)
    return {
        "room": room_name(vid),
        "ingress_id": info.ingress_id,
        "whip_url": f"{WHIP_BASE_URL.rstrip('/')}/{info.stream_key}",
        "publish_token": info.stream_key,
    }


@app.post("/{vid}/livestream/expect", dependencies=[Depends(require_auth)])
async def expect_stream(vid: str):
    """
    Called by BC immediately after it sends CMD_LIVESTREAM_ENABLE over MQTT.

    Marks the vehicle as STARTING and arms a timeout. If no video arrives, the
    state becomes FAILED_TO_START instead of sitting in limbo — so the system
    never claims a vehicle is streaming when it is not.
    """
    check_id(vid)
    cur = await read_state(vid)
    if cur.get("state") == STATE_STREAMING:
        return {"state": STATE_STREAMING, "room": room_name(vid),
                "already_streaming": True}
    await ensure_ingress(vid)   # safety net if provision was never called
    doc = await write_state(vid, STATE_STARTING)
    await arm_watchdog(vid)
    return {**doc, "timeout_s": PUBLISH_TIMEOUT_S}


@app.post("/{vid}/livestream/token", dependencies=[Depends(require_auth)])
async def viewer_token(vid: str, request: Request):
    """
    One viewing pass per viewer. Scoped to this vehicle's room, subscribe-only.

    Never contacts the vehicle: if the stream is already live this is a pure
    lookup, which is why the second and later viewers cost the vehicle nothing.

    ?wait=true blocks until the stream comes up (useful right after BC has sent
    a start command); default returns 409 if it is not live yet.
    """
    check_id(vid)
    identity = request.query_params.get(
        "identity", f"viewer-{secrets.token_hex(6)}")
    wait = request.query_params.get("wait", "false").lower() == "true"

    cur = await read_state(vid)
    if cur.get("state") != STATE_STREAMING and wait:
        cur = await wait_for_streaming(vid, PUBLISH_TIMEOUT_S + 2)
    if cur.get("state") != STATE_STREAMING:
        raise HTTPException(409, {"state": cur.get("state"),
                                  "detail": "vehicle is not streaming"})

    return {
        "url": LIVEKIT_WS_URL,
        "token": mint_viewer_token(vid, identity),
        "room": room_name(vid),
        "identity": identity,
        "expires_in": VIEWER_TOKEN_TTL_S,
    }


async def wait_for_streaming(vid: str, timeout: float) -> Dict[str, Any]:
    room = room_name(vid)
    q: asyncio.Queue = asyncio.Queue()
    subscribers.setdefault(room, set()).add(q)
    try:
        cur = await read_state(vid)
        if cur.get("state") == STATE_STREAMING:
            return cur
        deadline = time.monotonic() + timeout
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return await read_state(vid)
            try:
                evt = await asyncio.wait_for(q.get(), timeout=remaining)
            except asyncio.TimeoutError:
                return await read_state(vid)
            if evt.get("state") in (STATE_STREAMING, STATE_FAILED):
                return evt
    finally:
        subscribers.get(room, set()).discard(q)


@app.get("/{vid}/livestream/state", dependencies=[Depends(require_auth)])
async def get_state(vid: str):
    check_id(vid)
    return await read_state(vid)


@app.get("/{vid}/livestream/events", dependencies=[Depends(require_auth)])
async def events(vid: str):
    """SSE feed: STARTING / STREAMING / DISABLED / FAILED_TO_START."""
    check_id(vid)
    room = room_name(vid)
    q: asyncio.Queue = asyncio.Queue()
    subscribers.setdefault(room, set()).add(q)

    async def gen():
        try:
            yield f"data: {json.dumps(await read_state(vid))}\n\n"
            while True:
                try:
                    evt = await asyncio.wait_for(q.get(), timeout=15)
                    yield f"data: {json.dumps(evt)}\n\n"
                except asyncio.TimeoutError:
                    yield ": keepalive\n\n"
        finally:
            subscribers.get(room, set()).discard(q)

    return StreamingResponse(gen(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache"})


# --------------------------------------------------------------------------
# LiveKit webhook — the only trustworthy "video is real" signal
# --------------------------------------------------------------------------

_receiver = api.WebhookReceiver(
    api.TokenVerifier(LIVEKIT_API_KEY, LIVEKIT_API_SECRET))


@app.post("/system/webhooks/livekit")
async def livekit_webhook(request: Request, authorization: Optional[str] = Header(None)):
    body = (await request.body()).decode()
    try:
        event = _receiver.receive(body, authorization)
    except Exception as exc:  # noqa: BLE001
        log.warning("rejected webhook: %s", exc)
        raise HTTPException(401, "webhook verification failed")

    room = event.room.name if event.room and event.room.name else ""
    if not ID_RE.match(room):
        return JSONResponse({"ok": True, "ignored": "room is not a vehicle id"})
    vid = room
    log.info("webhook %s room=%s", event.event, room)

    if event.event == "track_published":
        t = watchdogs.pop(room, None)
        if t:
            t.cancel()
        await write_state(vid, STATE_STREAMING,
                          participant=event.participant.identity
                          if event.participant else None)
    elif event.event in ("participant_left", "room_finished", "ingress_ended"):
        cur = await read_state(vid)
        if cur.get("state") in (STATE_STREAMING, STATE_STARTING):
            await write_state(vid, STATE_DISABLED)

    return {"ok": True}


@app.get("/healthz")
async def healthz():
    return {"ok": True, "livekit": LIVEKIT_HTTP_URL,
            "whip_base_url": WHIP_BASE_URL, "viewer_url": LIVEKIT_WS_URL}
