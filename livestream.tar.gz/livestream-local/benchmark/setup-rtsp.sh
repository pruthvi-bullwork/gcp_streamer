#!/usr/bin/env bash
# MediaMTX on the laptop, as the RTSP half of the comparison.
#
#   ./setup-rtsp.sh          # download and run
#   ./setup-rtsp.sh stop
#
# It runs on the LAPTOP, not the Jetson — deliberately. LiveKit is on the
# laptop, so if MediaMTX ran on the Jetson the two tests would have different
# topologies and the comparison would be worthless. Both must be
# Jetson -> laptop -> viewer.
set -euo pipefail
cd "$(dirname "$0")"

VER=1.9.3
BIN=./bin/mediamtx

if [ "${1:-run}" = "stop" ]; then
  pkill -f "mediamtx" && echo "mediamtx stopped" || echo "not running"
  exit 0
fi

mkdir -p bin results
if [ ! -x "$BIN" ]; then
  echo "downloading mediamtx ${VER}..."
  curl -sSL -o /tmp/mediamtx.tgz \
    "https://github.com/bluenviron/mediamtx/releases/download/v${VER}/mediamtx_v${VER}_linux_amd64.tar.gz"
  tar xzf /tmp/mediamtx.tgz -C bin mediamtx
fi

cat > mediamtx.yml <<'EOF'
# Minimal config: RTSP in and out, nothing else. WebRTC and HLS are disabled
# so this is a like-for-like RTSP comparison against LiveKit rather than
# MediaMTX's own WebRTC stack.
logLevel: info
rtsp: yes
rtspAddress: :8554
protocols: [udp, tcp]
webrtc: no
hls: no
rtmp: no
srt: no
paths:
  bench:
    source: publisher
EOF

pkill -f "mediamtx" 2>/dev/null || true
nohup "$BIN" mediamtx.yml > results/mediamtx.log 2>&1 &
disown
sleep 2

if pgrep -f mediamtx >/dev/null; then
  IP=$(ip -4 route get 1.1.1.1 2>/dev/null | awk '{print $7; exit}')
  echo "mediamtx up"
  echo "  publish to : rtsp://${IP:-<laptop-ip>}:8554/bench"
  echo "  play from  : rtsp://${IP:-<laptop-ip>}:8554/bench"
  echo
  echo "Open 8554/tcp and 8000-8001/udp on the laptop firewall if ufw is on."
else
  echo "failed to start:"
  sed 's/^/  /' results/mediamtx.log | tail -5
  echo
  echo "If it names an unknown config field, your mediamtx version uses"
  echo "different key names — check ./bin/mediamtx --version and the release"
  echo "notes, or delete mediamtx.yml to run with defaults."
  exit 1
fi
