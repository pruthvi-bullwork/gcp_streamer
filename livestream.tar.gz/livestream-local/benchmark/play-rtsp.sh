#!/usr/bin/env bash
# Play the RTSP stream with buffering turned down, so the comparison measures
# the transport rather than a player's default queue.
#
#   ./play-rtsp.sh rtsp://192.168.0.162:8554/bench
#   ./play-rtsp.sh rtsp://192.168.0.162:8554/bench vlc-default
#
# Most published "RTSP is 1-2 seconds" numbers are really VLC's one-second
# buffer, not RTSP. Run both modes and you will see the gap close.
set -euo pipefail
URL=${1:?usage: $0 <rtsp url> [vlc-default]}
MODE=${2:-low-latency}

if [ "$MODE" = "vlc-default" ]; then
  echo "playing with default buffering — this is the number people usually quote"
  exec ffplay -rtsp_transport udp "$URL"
fi

echo "playing with low-latency flags"
echo "  no buffering, no frame queue, UDP transport"
exec ffplay \
  -rtsp_transport udp \
  -fflags nobuffer \
  -flags low_delay \
  -probesize 32 \
  -analyzeduration 0 \
  -framedrop \
  -sync ext \
  "$URL"
