# WebRTC vs RTSP — local benchmark

Measures both transports on your own hardware and network so the choice rests
on numbers rather than on what a comparison table asserts.

Topology is identical for both. Only the transport changes:

```
Jetson (ZED or test pattern, nvv4l2h264enc)
        │
        ├── WHIP ──────►  LiveKit on the laptop  ──►  browser
        └── RTSP ──────►  MediaMTX on the laptop ──►  ffplay
```

Both servers run on the **laptop**, not the Jetson. If MediaMTX ran on the
Jetson while LiveKit ran on the laptop, the two tests would have different
network paths and the result would mean nothing.

---

## Corrections to the usual comparison

Worth knowing before you interpret the numbers, because several widely repeated
claims do not survive measurement:

**"RTSP uses TCP, WebRTC uses UDP."** RTSP *signalling* is TCP; its media is
RTP over UDP by default — the same transport WebRTC uses. TCP interleaving is
an option, rarely used, and slower.

**"RTSP retries dropped packets, WebRTC drops them."** WebRTC has NACK
retransmission and FEC. Over UDP, RTSP has neither.

**"RTSP is far lighter on the Jetson."** Both feed the same
`nvv4l2h264enc` hardware encoder. WebRTC adds SRTP encryption, which on an
Orin is small next to encode. Measure it rather than assuming — that is what
`measure.py` is for.

**"RTSP latency is 500 ms to 2 s."** That is player buffering, not protocol.
`ffplay` with `-fflags nobuffer -flags low_delay` reaches well under 200 ms on
a LAN. `play-rtsp.sh` runs both settings so you can see the difference come
from the player.

The real differences are architectural, and no benchmark will change them:

| | WebRTC / LiveKit | RTSP |
|---|---|---|
| Plays in a browser | Yes, natively | No — needs a player app or conversion |
| Multiple viewers | SFU fans out; vehicle sends once | Server must relay; vehicle sends once to the server |
| Works through carrier NAT | Yes, with TURN | Usually not, without a VPN or relay |
| Encryption | Mandatory (SRTP/DTLS) | Optional, rarely configured |
| Adapts to a weak viewer link | Yes, per subscriber | No |

---

## The single-script version

`compare_stream.py` does the whole thing in one process: subscribes to the ZED
topic, encodes once, and tees the identical stream into both transports at the
same time.

```bash
./compare_stream.py \
  --whip http://<laptop>:8070/w/<stream_key> \
  --rtsp rtsp://<laptop>:8554/bench \
  --topic /zed/zed_node/rgb/image_rect_color/compressed \
  --seconds 60 --label zed-both
```

Running both together is deliberate: the frames are byte-identical and the
encode is paid once, so anything the table shows is caused by the transport
rather than by scene changes or encoder variation between two separate runs.

It prints a live table each second and a summary at the end, and writes CSV
and JSON into `results/`. Use `--source test` for a test pattern instead of
the camera, and give only `--whip` or only `--rtsp` to run one alone.

Note what the CPU figure means here: one encode feeds both branches, so it is
the total for the pipeline and cannot be attributed to either transport. To
cost them separately, run each alone and compare — or use `measure.py` below.

## Running the separate-session version

**On the laptop:**

```bash
./start.sh                      # LiveKit, from the main folder
cd benchmark && ./setup-rtsp.sh # MediaMTX
```

Get a WHIP URL for the WebRTC run:

```bash
source ../stack.env
curl -sX POST http://localhost:$COMMANDER_PORT/bench/livestream/provision \
  -H "Authorization: Bearer $COMMANDER_API_TOKEN" | jq -r .whip_url
```

**On the Jetson**, one transport at a time:

```bash
# WebRTC
./publish.sh webrtc http://<laptop>:8070/w/<stream_key>

# RTSP
./publish.sh rtsp rtsp://<laptop>:8554/bench
```

Same source, same encoder settings, same burnt-in clock in both.

**Viewing:**

```bash
# WebRTC — browser
./test/flow.sh token bench        # from the main folder, prints a URL

# RTSP
./play-rtsp.sh rtsp://<laptop>:8554/bench
./play-rtsp.sh rtsp://<laptop>:8554/bench vlc-default   # for contrast
```

---

## What to measure

### Jetson cost

On the Jetson, while each stream is running and settled:

```bash
./measure.py --label webrtc --seconds 60
./measure.py --label rtsp   --seconds 60
./measure.py --compare
```

Reads `tegrastats` — CPU per core, GPU, NVENC, RAM and power. Watch **power**
rather than CPU percentage: the encoder is a separate block, so a pipeline can
look idle on CPU while drawing real watts.

A difference under about 5% is run-to-run noise on a Jetson. If that is what
you get, the two are equivalent on cost and the decision rests elsewhere.

### Latency

The only honest measure is glass-to-glass, and it needs a camera.

Both pipelines burn a millisecond clock into the video. Put the Jetson's
display and the viewer's display side by side, photograph both at once, and
subtract the two timestamps. Repeat five times and take the median — a single
photo catches whatever phase the frame interval happened to be in.

Do the RTSP side twice, with and without the low-latency flags. That
difference is the player, and it is usually larger than the difference between
the two protocols.

### Stream quality

The browser viewer's footer shows bitrate, jitter buffer, packet loss and
decoded frames, with a "Record 60s" button that summarises a run and exports
CSV. For RTSP, `ffplay` prints frame drops and A/V drift in its status line.

---

## Reading the result

Expect the numbers to come out closer than the usual comparison suggests,
because both use the same encoder and the same UDP transport. If they do, the
decision is not about performance at all — it is about whether operators watch
in a browser, whether more than one person watches at once, and whether
vehicles are behind carrier NAT.

On the current design all three point the same way. But measuring is still
worth the afternoon: if WebRTC turns out to cost meaningfully more power on
the Jetson, that is a real finding on a battery-powered vehicle, and better to
know it now.

One thing this benchmark cannot tell you: how either behaves over a real
cellular link. On a LAN there is no packet loss, no jitter and no NAT, which
is where the two diverge most. Treat the result as a hardware and pipeline
comparison, not a network one.
