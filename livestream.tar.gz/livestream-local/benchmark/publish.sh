#!/usr/bin/env bash
# Publish the same video over WebRTC (WHIP) or RTSP, with identical capture
# and encode settings, so the only variable is the transport.
#
#   ./publish.sh webrtc  http://192.168.0.162:8070/w/<stream_key>
#   ./publish.sh rtsp    rtsp://192.168.0.162:8554/bench
#
# Both paths use the same source, the same nvv4l2h264enc settings and the same
# burnt-in clock. Anything that differs between the two runs is the transport,
# not the pipeline.
set -euo pipefail
cd "$(dirname "$0")"

MODE=${1:?usage: $0 {webrtc|rtsp} <url>}
URL=${2:?missing url}

WIDTH=${WIDTH:-1280}
HEIGHT=${HEIGHT:-720}
FPS=${FPS:-20}
BITRATE_KBPS=${BITRATE_KBPS:-1200}
SOURCE=${SOURCE:-test}        # test | uvc | ros

# --- source ---------------------------------------------------------------
case "$SOURCE" in
  test)
    SRC="videotestsrc is-live=true pattern=ball ! video/x-raw,width=$WIDTH,height=$HEIGHT,framerate=$FPS/1"
    ;;
  uvc)
    FULL=$((WIDTH * 2))
    SRC="v4l2src device=${VIDEO_DEVICE:-/dev/video0} io-mode=2 ! video/x-raw,format=YUY2,width=$FULL,height=$HEIGHT,framerate=$FPS/1 ! videocrop right=$WIDTH"
    ;;
  *) echo "SOURCE must be test or uvc for the benchmark"; exit 1 ;;
esac

# A burnt-in millisecond clock is how glass-to-glass latency gets measured:
# photograph the Jetson's screen and the viewer's screen together and subtract.
CLOCK='clockoverlay time-format="%H:%M:%S" halignment=left valignment=top font-desc="Mono 28" ! timeoverlay halignment=right valignment=top font-desc="Mono 28"'

ENC="nvvidconv ! video/x-raw(memory:NVMM),format=NV12 ! \
nvv4l2h264enc bitrate=$((BITRATE_KBPS * 1000)) control-rate=1 preset-level=1 \
profile=0 iframeinterval=$((FPS * 2)) idrinterval=$((FPS * 2)) \
insert-sps-pps=true insert-vui=true maxperf-enable=true"

if ! gst-inspect-1.0 nvv4l2h264enc >/dev/null 2>&1; then
  echo "WARNING: no hardware encoder here — falling back to x264enc."
  echo "         CPU numbers from this run will not represent the Jetson."
  ENC="videoconvert ! x264enc tune=zerolatency speed-preset=ultrafast bitrate=$BITRATE_KBPS key-int-max=$((FPS * 2)) ! video/x-h264,profile=constrained-baseline"
fi

echo "mode=$MODE source=$SOURCE ${WIDTH}x${HEIGHT}@${FPS} ${BITRATE_KBPS}kbps"
echo "target: $URL"
echo

case "$MODE" in
  rtsp)
    if ! gst-inspect-1.0 rtspclientsink >/dev/null 2>&1; then
      echo "rtspclientsink missing — install gstreamer1.0-rtsp"
      exit 1
    fi
    exec gst-launch-1.0 -v $SRC ! $CLOCK ! $ENC ! h264parse config-interval=-1 ! \
      rtspclientsink location="$URL" latency=0 protocols=udp
    ;;

  webrtc)
    # No whipclientsink on JetPack's GStreamer, so reuse the agent's webrtcbin
    # WHIP client. AUTOSTART skips MQTT entirely.
    export WHIP_URL="$URL"
    export PUBLISH_TOKEN="${PUBLISH_TOKEN:-$(basename "$URL")}"
    export AUTOSTART=true SOURCE WIDTH HEIGHT FPS BITRATE_KBPS
    exec python3 ../jetson/vehicle_agent.py
    ;;

  *) echo "mode must be webrtc or rtsp"; exit 1 ;;
esac
