#!/usr/bin/env python3
"""
WebRTC vs RTSP, measured side by side from one encode.

Subscribes to a ZED ROS2 topic, encodes H264 once on the Jetson's hardware
encoder, then tees the identical elementary stream into both transports at the
same time:

    ZED topic ─► decode ─► nvv4l2h264enc ─► tee ─┬─► RTP ─► webrtcbin ─► WHIP
                                                 └─► rtspclientsink ─► RTSP

Running both together is the point. The frames are byte-identical and the
encoder cost is paid once, so every difference the table prints is caused by
the transport and nothing else. Running them in separate sessions would let
encoder variation and scene changes contaminate the comparison.

    ./compare_stream.py --whip http://laptop:8070/w/KEY \\
                        --rtsp rtsp://laptop:8554/bench --seconds 60

    ./compare_stream.py --whip ... --seconds 60          # WebRTC only
    ./compare_stream.py --rtsp ... --seconds 60          # RTSP only
    ./compare_stream.py --whip ... --rtsp ... --source test

Writes a CSV and prints a summary suitable for pasting into a document.
"""

from __future__ import annotations

import argparse
import csv
import json
import pathlib
import re
import shutil
import statistics
import subprocess
import sys
import threading
import time
from urllib.parse import urljoin

import gi

gi.require_version("Gst", "1.0")
gi.require_version("GstSdp", "1.0")
gi.require_version("GstWebRTC", "1.0")
from gi.repository import GLib, Gst, GstSdp, GstWebRTC  # noqa: E402

import requests  # noqa: E402

OUT = pathlib.Path(__file__).parent / "results"


# --------------------------------------------------------------------------
# counters
# --------------------------------------------------------------------------

class Branch:
    """Bytes and packets that actually left through one transport."""

    def __init__(self, name: str) -> None:
        self.name = name
        self.bytes = 0
        self.packets = 0
        self.state = "-"
        self.rtt_ms = None
        self.lock = threading.Lock()

    def add(self, nbytes: int) -> None:
        with self.lock:
            self.bytes += nbytes
            self.packets += 1

    def snapshot(self) -> tuple:
        with self.lock:
            return self.bytes, self.packets


def probe(pad, info, branch: Branch):
    buf = info.get_buffer()
    if buf is not None:
        branch.add(buf.get_size())
        return Gst.PadProbeReturn.OK
    bl = info.get_buffer_list()
    if bl is not None:
        for i in range(bl.length()):
            branch.add(bl.get(i).get_size())
    return Gst.PadProbeReturn.OK


PROBE_MASK = Gst.PadProbeType.BUFFER | Gst.PadProbeType.BUFFER_LIST


# --------------------------------------------------------------------------
# pipeline
# --------------------------------------------------------------------------

def have(el: str) -> bool:
    return Gst.ElementFactory.find(el) is not None


def build(args, want_webrtc: bool, want_rtsp: bool) -> str:
    fps, w, h = args.fps, args.width, args.height

    if args.source == "test":
        clock = ('clockoverlay time-format="%H:%M:%S" halignment=left '
                 'valignment=top font-desc="Mono 26" ! ') if have("clockoverlay") else ""
        src = (f"videotestsrc is-live=true pattern=ball ! "
               f"video/x-raw,width={w},height={h},framerate={fps}/1 ! {clock}videoconvert")
    else:
        # Frames arrive from the ROS subscriber through appsrc.
        if args.compressed:
            dec = "nvjpegdec" if have("nvjpegdec") else "jpegdec ! videoconvert"
            src = ("appsrc name=rossrc is-live=true do-timestamp=true format=time "
                   f"block=false max-bytes=8000000 ! jpegparse ! {dec}")
        else:
            src = ("appsrc name=rossrc is-live=true do-timestamp=true format=time "
                   "block=false max-bytes=8000000 ! videoconvert")

    if have("nvv4l2h264enc"):
        enc = ("nvvidconv ! video/x-raw(memory:NVMM),format=NV12 ! "
               f"nvv4l2h264enc bitrate={args.bitrate * 1000} "
               f"control-rate={1 if args.cbr else 0} "
               f"preset-level=1 profile=0 iframeinterval={fps * 2} "
               f"idrinterval={fps * 2} insert-sps-pps=true insert-vui=true "
               "maxperf-enable=true")
        enc_kind = "nvv4l2h264enc (hardware)"
    else:
        enc = (f"videoconvert ! x264enc tune=zerolatency speed-preset=ultrafast "
               f"bitrate={args.bitrate} key-int-max={fps * 2} ! "
               "video/x-h264,profile=constrained-baseline")
        enc_kind = "x264enc (software)"

    parts = [f"{src} ! {enc} ! h264parse config-interval=-1 ! "
             "video/x-h264,stream-format=byte-stream,alignment=au ! tee name=t"]

    if want_webrtc:
        parts.append(
            "t. ! queue name=q_webrtc max-size-buffers=0 max-size-bytes=0 "
            "max-size-time=200000000 leaky=downstream ! "
            "rtph264pay name=pay config-interval=-1 aggregate-mode=zero-latency pt=96 ! "
            "application/x-rtp,media=video,encoding-name=H264,payload=96,clock-rate=90000 ! "
            "webrtcbin name=whip bundle-policy=max-bundle latency=0")

    if want_rtsp:
        parts.append(
            "t. ! queue name=q_rtsp max-size-buffers=0 max-size-bytes=0 "
            "max-size-time=200000000 leaky=downstream ! "
            "h264parse name=rtspparse ! "
            f"rtspclientsink name=rtspsink location={args.rtsp} latency=0 protocols=udp")

    return " ".join(parts), enc_kind


# --------------------------------------------------------------------------
# WHIP
# --------------------------------------------------------------------------

class Whip:
    def __init__(self, webrtc, url: str, token: str, branch: Branch) -> None:
        self.webrtc = webrtc
        self.url = url
        self.token = token
        self.branch = branch
        self.resource = None
        self.sent = False
        self.attempts = 0
        webrtc.connect("on-negotiation-needed", self._negotiate)
        webrtc.connect("notify::ice-gathering-state", self._gathering)
        webrtc.connect("notify::connection-state", self._conn)

    def _negotiate(self, el) -> None:
        self._create_offer(el)

    def _create_offer(self, el) -> bool:
        tr = el.emit("get-transceiver", 0)
        if tr:
            tr.set_property("direction",
                            GstWebRTC.WebRTCRTPTransceiverDirection.SENDONLY)
        el.emit("create-offer", None,
                Gst.Promise.new_with_change_func(self._offer, el, None))
        return False

    def _offer(self, promise, el, _) -> None:
        # With a tee feeding two branches, negotiation can fire before caps
        # have settled on this one. create-offer then returns an empty reply,
        # and passing that to set-local-description aborts inside webrtcbin.
        reply = promise.get_reply()
        offer = reply.get_value("offer") if reply else None
        if offer is None:
            self.attempts += 1
            if self.attempts > 10:
                self.branch.state = "offer failed"
                print("\n  webrtc: create-offer kept returning nothing — "
                      "check that the branch has caps")
                return
            self.branch.state = f"negotiating (retry {self.attempts})"
            GLib.timeout_add(300, self._create_offer, el)
            return
        el.emit("set-local-description", offer, Gst.Promise.new())

    def _gathering(self, el, _p) -> None:
        st = el.get_property("ice-gathering-state")
        self.branch.state = f"ice:{st.value_nick}"
        if st == GstWebRTC.WebRTCICEGatheringState.COMPLETE and not self.sent:
            self.sent = True
            threading.Thread(target=self._post, daemon=True).start()

    def _post(self) -> None:
        sdp = self.webrtc.get_property("local-description").sdp.as_text()
        try:
            r = requests.post(self.url, data=sdp.encode(),
                              headers={"Content-Type": "application/sdp",
                                       "Authorization": f"Bearer {self.token}"},
                              timeout=15)
            r.raise_for_status()
        except Exception as exc:  # noqa: BLE001
            self.branch.state = f"whip failed: {exc}"
            return
        loc = r.headers.get("Location")
        self.resource = urljoin(r.url, loc) if loc else None
        GLib.idle_add(self._answer, r.text)

    def _answer(self, text: str) -> bool:
        res, sdp = GstSdp.SDPMessage.new_from_text(text)
        if res != GstSdp.SDPResult.OK:
            self.branch.state = "bad answer"
            return False
        ans = GstWebRTC.WebRTCSessionDescription.new(
            GstWebRTC.WebRTCSDPType.ANSWER, sdp)
        self.webrtc.emit("set-remote-description", ans, Gst.Promise.new())
        return False

    def _conn(self, el, _p) -> None:
        self.branch.state = el.get_property("connection-state").value_nick

    def stop(self) -> None:
        if self.resource:
            try:
                requests.delete(self.resource,
                                headers={"Authorization": f"Bearer {self.token}"},
                                timeout=5)
            except Exception:  # noqa: BLE001
                pass


# --------------------------------------------------------------------------
# ROS
# --------------------------------------------------------------------------

class Ros:
    ENC = {"bgra8": "BGRA", "rgba8": "RGBA", "bgr8": "BGR",
           "rgb8": "RGB", "mono8": "GRAY8"}

    def __init__(self, topic: str, compressed: bool, appsrc, fps: int) -> None:
        import rclpy
        from sensor_msgs.msg import CompressedImage, Image

        self.appsrc = appsrc
        self.fps = fps
        self.compressed = compressed
        self.caps = None
        self.frames = 0
        rclpy.init(args=None)
        self.node = rclpy.create_node("stream_benchmark")
        if compressed:
            self.node.create_subscription(CompressedImage, topic, self._compressed, 1)
        else:
            self.node.create_subscription(Image, topic, self._raw, 1)
        self._rclpy = rclpy
        self._spin = threading.Thread(target=self._spin_loop, daemon=True)
        self._spin.start()

    def _spin_loop(self) -> None:
        try:
            self._rclpy.spin(self.node)
        except Exception:  # noqa: BLE001
            pass

    def stop(self) -> None:
        """Shut ROS down before the process exits. Leaving the executor
        running while the interpreter tears down aborts in native code."""
        try:
            self._rclpy.shutdown()
        except Exception:  # noqa: BLE001
            pass
        self._spin.join(timeout=2)

    def _compressed(self, msg) -> None:
        if self.caps is None:
            self.caps = Gst.Caps.from_string(f"image/jpeg,framerate={self.fps}/1")
            self.appsrc.set_property("caps", self.caps)
        self.frames += 1
        self.appsrc.emit("push-buffer", Gst.Buffer.new_wrapped(bytes(msg.data)))

    def _raw(self, msg) -> None:
        fmt = self.ENC.get(msg.encoding)
        if fmt is None:
            return
        if self.caps is None:
            self.caps = Gst.Caps.from_string(
                f"video/x-raw,format={fmt},width={msg.width},"
                f"height={msg.height},framerate={self.fps}/1")
            self.appsrc.set_property("caps", self.caps)
        self.frames += 1
        self.appsrc.emit("push-buffer", Gst.Buffer.new_wrapped(bytes(msg.data)))


# --------------------------------------------------------------------------
# system sampling
# --------------------------------------------------------------------------

CPU_RE = re.compile(r"CPU \[([^\]]+)\]")
VDD_RE = re.compile(r"VDD_IN (\d+)mW")


class System:
    """tegrastats where present, psutil otherwise. One encode feeds both
    branches, so this is the cost of the whole pipeline, not of one transport
    — useful as a total, not as an attribution."""

    def __init__(self) -> None:
        self.cpu = None
        self.power_w = None
        self.proc = None
        if shutil.which("tegrastats"):
            self.proc = subprocess.Popen(["tegrastats", "--interval", "1000"],
                                         stdout=subprocess.PIPE, text=True)
            threading.Thread(target=self._read_tegra, daemon=True).start()
        else:
            try:
                import psutil
                self._psutil = psutil
            except ImportError:
                self._psutil = None

    def _read_tegra(self) -> None:
        for line in self.proc.stdout:
            m = CPU_RE.search(line)
            if m:
                loads = [float(p.split("%")[0]) for p in m.group(1).split(",")
                         if not p.startswith("off")]
                self.cpu = round(statistics.fmean(loads), 1) if loads else None
            v = VDD_RE.search(line)
            if v:
                self.power_w = round(int(v.group(1)) / 1000, 2)

    def sample(self) -> None:
        if self.proc is None and getattr(self, "_psutil", None):
            self.cpu = self._psutil.cpu_percent(interval=None)

    def stop(self) -> None:
        if self.proc:
            self.proc.terminate()


# --------------------------------------------------------------------------
# main
# --------------------------------------------------------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--whip", help="WHIP URL, e.g. http://laptop:8070/w/KEY")
    ap.add_argument("--rtsp", help="RTSP URL, e.g. rtsp://laptop:8554/bench")
    ap.add_argument("--token", default="", help="WHIP bearer (defaults to the key in the URL)")
    ap.add_argument("--topic", default="/zed/zed_node/rgb/image_rect_color/compressed")
    ap.add_argument("--source", choices=["ros", "test"], default="ros")
    ap.add_argument("--compressed", action="store_true", default=None,
                    help="topic is CompressedImage (auto-detected from the name)")
    ap.add_argument("--width", type=int, default=1280)
    ap.add_argument("--height", type=int, default=720)
    ap.add_argument("--fps", type=int, default=20)
    ap.add_argument("--bitrate", type=int, default=1200, help="kbps")
    ap.add_argument("--vbr", dest="cbr", action="store_false", default=True,
                    help="variable bitrate (control-rate=0). Default is CBR "
                         "(control-rate=1), which is also what the production "
                         "agent uses.")
    ap.add_argument("--seconds", type=int, default=60)
    ap.add_argument("--label", default="compare")
    ap.add_argument("--baseline", action="store_true",
                    help="sample the machine with nothing streaming, so the "
                         "cost of the pipeline can be separated from whatever "
                         "else is already running on the Jetson")
    args = ap.parse_args()

    if args.baseline:
        baseline(args.seconds)
        return
    if not args.whip and not args.rtsp:
        ap.error("give --whip, --rtsp, both, or --baseline")
    if args.compressed is None:
        args.compressed = args.topic.rstrip("/").endswith("compressed")
    if args.whip and not args.token:
        args.token = args.whip.rstrip("/").rsplit("/", 1)[-1]

    Gst.init(None)
    OUT.mkdir(exist_ok=True)

    desc, enc_kind = build(args, bool(args.whip), bool(args.rtsp))
    print(f"encoder: {enc_kind}")
    print(f"source : {args.source}"
          + (f" {args.topic} ({'jpeg' if args.compressed else 'raw'})"
             if args.source == "ros" else ""))
    print(f"target : {args.width}x{args.height}@{args.fps} {args.bitrate} kbps")
    print(f"\npipeline:\n  {desc}\n")

    pipeline = Gst.parse_launch(desc)

    branches: dict[str, Branch] = {}
    whip = None

    rtp = Branch("webrtc-rtp")

    if args.whip:
        b = Branch("webrtc")
        branches["webrtc"] = b
        # Both branches are probed at the same stage — encoded access units
        # leaving the tee — so the two columns measure the same thing. The
        # earlier version probed RTP on one side and frames on the other,
        # which is not a comparison.
        pipeline.get_by_name("q_webrtc").get_static_pad("src") \
            .add_probe(PROBE_MASK, probe, b)
        # Packetisation is only visible on this side: rtspclientsink payloads
        # internally, so there is no pad to probe for it.
        pipeline.get_by_name("pay").get_static_pad("src") \
            .add_probe(PROBE_MASK, probe, rtp)
        webrtc = pipeline.get_by_name("whip")
        whip = Whip(webrtc, args.whip, args.token, b)

    rtspsink = None
    if args.rtsp:
        b = Branch("rtsp")
        branches["rtsp"] = b
        pipeline.get_by_name("q_rtsp").get_static_pad("src") \
            .add_probe(PROBE_MASK, probe, b)
        rtspsink = pipeline.get_by_name("rtspsink")
        b.state = "connecting"

    ros = None
    if args.source == "ros":
        appsrc = pipeline.get_by_name("rossrc")
        try:
            ros = Ros(args.topic, args.compressed, appsrc, args.fps)
        except ImportError as exc:
            sys.exit(f"ROS not importable ({exc}). Source your ROS setup, "
                     f"or use --source test.")

    bus = pipeline.get_bus()
    bus.add_signal_watch()

    def on_error(_b, msg):
        err, dbg = msg.parse_error()
        print(f"\nPIPELINE ERROR: {err}\n{dbg}")
        loop.quit()

    bus.connect("message::error", on_error)
    pipeline.set_state(Gst.State.PLAYING)

    loop = GLib.MainLoop()
    sysmon = System()
    rows: list[dict] = []
    started = time.time()
    prev = {n: (0, 0) for n in branches}
    prev_rtp = (0, 0)
    prev_frames = 0

    hdr = f"{'t':>4} {'fps':>5} " + "".join(
        f"{n + ' kbps':>13}{n + ' pps':>11}" for n in branches) + f"{'cpu%':>7}{'W':>7}"

    def tick() -> bool:
        nonlocal prev, prev_frames, prev_rtp
        el = time.time() - started
        if el > args.seconds:
            loop.quit()
            return False

        sysmon.sample()
        if rtspsink is not None:
            st = rtspsink.get_state(0)[1].value_nick
            b = branches["rtsp"]
            # Data moving while PLAYING is the only real confirmation; the
            # element reports PLAYING before the server has accepted anything.
            b.state = "streaming" if (st == "playing" and b.packets > 0) else st
        row = {"t": round(el, 1), "cpu_pct": sysmon.cpu, "power_w": sysmon.power_w}

        frames = ros.frames if ros else 0
        row["src_fps"] = frames - prev_frames
        prev_frames = frames

        line = f"{el:4.0f} {row['src_fps']:5d} "
        for n, b in branches.items():
            by, pk = b.snapshot()
            d_by, d_pk = by - prev[n][0], pk - prev[n][1]
            prev[n] = (by, pk)
            kbps = d_by * 8 / 1000
            row[f"{n}_kbps"] = round(kbps, 1)
            row[f"{n}_pps"] = d_pk
            row[f"{n}_state"] = b.state
            line += f"{kbps:13.0f}{d_pk:11d}"
        by, pk = rtp.snapshot()
        row["rtp_kbps"] = round((by - prev_rtp[0]) * 8 / 1000, 1)
        row["rtp_pps"] = pk - prev_rtp[1]
        prev_rtp = (by, pk)
        line += f"{(sysmon.cpu or 0):7.1f}{(sysmon.power_w or 0):7.2f}"

        rows.append(row)
        if len(rows) % 20 == 1:
            print(hdr)
        print(line)
        return True

    GLib.timeout_add_seconds(1, tick)
    print(f"running for {args.seconds}s — ctrl-c to stop early\n")

    try:
        loop.run()
    except KeyboardInterrupt:
        pass
    finally:
        if whip:
            whip.stop()
        pipeline.set_state(Gst.State.NULL)
        pipeline.get_state(Gst.CLOCK_TIME_NONE)   # wait for teardown
        if ros:
            ros.stop()
        sysmon.stop()

    report(args, branches, rows, enc_kind)


def baseline(seconds: int) -> None:
    """The Jetson is running a lot besides this. Without a baseline, the CPU
    and power figures are the whole machine, not the stream."""
    print(f"sampling with nothing streaming for {seconds}s")
    sysmon = System()
    vals = []
    for i in range(seconds):
        time.sleep(1)
        sysmon.sample()
        if sysmon.cpu is not None:
            vals.append((sysmon.cpu, sysmon.power_w or 0))
            print(f"\r  {i+1}/{seconds}s  cpu {sysmon.cpu:5.1f}%  "
                  f"{sysmon.power_w or 0:5.2f}W", end="", flush=True)
    sysmon.stop()
    print()
    if not vals:
        print("no samples")
        return
    cpu = statistics.fmean(v[0] for v in vals)
    pw = statistics.fmean(v[1] for v in vals)
    OUT.mkdir(exist_ok=True)
    (OUT / "baseline.json").write_text(
        json.dumps({"cpu_pct": round(cpu, 1), "power_w": round(pw, 2)}, indent=2))
    print(f"\nbaseline: cpu {cpu:.1f} %   power {pw:.2f} W")
    print("Subtract these from a streaming run to get the cost of the pipeline.")


def report(args, branches, rows, enc_kind) -> None:
    if not rows:
        print("no samples")
        return

    # Ignore the first few seconds: connection setup and the first keyframe
    # distort the averages.
    warm = [r for r in rows if r["t"] > 5] or rows

    def avg(k):
        vals = [r[k] for r in warm if r.get(k) is not None]
        return round(statistics.fmean(vals), 1) if vals else None

    OUT.mkdir(exist_ok=True)
    csv_path = OUT / f"{args.label}.csv"
    cols = sorted({k for r in rows for k in r})
    with csv_path.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        w.writerows(rows)

    print("\n" + "=" * 66)
    print(f"RESULT — {args.label}   ({len(warm)}s after warm-up, "
          f"{args.width}x{args.height}@{args.fps}, {args.bitrate} kbps target)")
    print("=" * 66)
    print(f"encoder        {enc_kind}")
    if args.source == "ros":
        print(f"source fps     {avg('src_fps')}  (topic {args.topic})")
    print(f"pipeline cpu   {avg('cpu_pct')} %"
          + (f"     power {avg('power_w')} W" if avg("power_w") else ""))
    base_file = OUT / "baseline.json"
    if base_file.exists():
        base = json.loads(base_file.read_text())
        dc = (avg("cpu_pct") or 0) - base["cpu_pct"]
        dp = (avg("power_w") or 0) - base["power_w"]
        print(f"  minus baseline ({base['cpu_pct']} %, {base['power_w']} W): "
              f"{dc:+.1f} % cpu, {dp:+.2f} W")
        summary_delta = {"cpu_pct": round(dc, 1), "power_w": round(dp, 2)}
    else:
        summary_delta = None
        print("  no baseline recorded — run with --baseline to separate this")
        print("  from whatever else the Jetson is already doing")
    print("  one encode feeds both branches, so this is the total for the")
    print("  pipeline — it is not attributable to either transport alone.\n")

    summary = {"label": args.label, "encoder": enc_kind,
               "above_baseline": summary_delta,
               "cpu_pct": avg("cpu_pct"), "power_w": avg("power_w"),
               "src_fps": avg("src_fps"), "branches": {}}

    print("encoded stream handed to each transport "
          "(same stage on both, so these should match):\n")
    print(f"{'transport':<12}{'kbps':>10}{'frames/s':>11}{'bytes/frame':>13}   state")
    for n, b in branches.items():
        kbps, fps_ = avg(f"{n}_kbps"), avg(f"{n}_pps")
        per = round(kbps * 125 / fps_) if kbps and fps_ else 0
        print(f"{n:<12}{kbps or 0:10.0f}{fps_ or 0:11.1f}{per:13d}   {b.state}")
        summary["branches"][n] = {"kbps": kbps, "frames_per_s": fps_,
                                  "bytes_per_frame": per, "state": b.state}

    rkbps, rpps = avg("rtp_kbps"), avg("rtp_pps")
    if rkbps:
        print(f"\nWebRTC packetisation: {rkbps:.0f} kbps in {rpps:.0f} RTP packets/s "
              f"({round(rkbps * 125 / rpps) if rpps else 0} bytes each)")
        print("  rtspclientsink payloads internally, so there is no equivalent")
        print("  figure for RTSP. Both use RTP at the same MTU, so packet counts")
        print("  would be close; RTSP saves the ~10-byte SRTP tag per packet,")
        print(f"  about {rpps * 10 * 8 / 1000:.0f} kbps at this rate.")
        summary["webrtc_rtp"] = {"kbps": rkbps, "pps": rpps}

    if len(branches) == 2:
        a, c = list(branches)
        ka, kc = summary["branches"][a]["kbps"], summary["branches"][c]["kbps"]
        if ka and kc:
            pct = 100 * abs(ka - kc) / max(ka, kc)
            if pct < 2:
                print(f"\nBoth transports received the same encoded stream "
                      f"({pct:.1f}% apart) —\nthe comparison is fair.")
            else:
                print(f"\nThe two branches differ by {pct:.1f}%, which should "
                      f"not happen from one\nencoder. Check whether a queue is "
                      f"dropping — both are leaky=downstream.")

    print("\nNot measured here: glass-to-glass latency. Both pipelines carry a")
    print("burnt-in clock — photograph the source and viewer screens together")
    print("and subtract. Five times, take the median.")
    print("\nA LAN has no loss, jitter or NAT, which is where the two diverge")
    print("most. This compares the pipeline, not the network.")

    (OUT / f"{args.label}.json").write_text(json.dumps(summary, indent=2))
    print(f"\nwrote {csv_path} and {OUT / (args.label + '.json')}")


if __name__ == "__main__":
    main()
