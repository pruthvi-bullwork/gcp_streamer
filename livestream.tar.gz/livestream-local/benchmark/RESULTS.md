# WebRTC vs RTSP — Measured Comparison

**Date:** 21 September 2026
**Hardware:** NVIDIA Jetson Orin, ZED 2i camera
**Method:** one encode, both transports simultaneously

---

## 1. How the test was run

Both transports were fed from a single encode, at the same time, from one
process:

```
ZED ROS2 topic ──► nvjpegdec ──► nvv4l2h264enc ──► tee ─┬─► RTP ─► WebRTC (WHIP) ─► LiveKit
                                                        └─► rtspclientsink ─► MediaMTX
```

Running both together rather than in separate sessions matters: the frames are
byte-identical and the encode is paid once, so any difference in the results
is caused by the transport and nothing else. Two separate runs would let scene
changes and encoder variation contaminate the comparison.

Both servers ran on the same laptop, on the same network, so neither transport
had a shorter path than the other.

| Setting | Value |
|---|---|
| Source | `/zed/zed_node/rgb/color/raw/image/compressed` (JPEG) |
| Decode | `nvjpegdec` — Jetson hardware JPEG engine |
| Encode | `nvv4l2h264enc` — Jetson hardware encoder, CBR |
| Target | 1280x720, 20 fps, 1200 kbps |
| Keyframe interval | 2 seconds |
| Run length | 60 s (first 5 s discarded as warm-up) |

---

## 2. Measured results

### Stream delivered to each transport

| Metric | WebRTC | RTSP |
|---|---|---|
| Bitrate | 1098 kbps | 1098 kbps |
| Frame rate | 18.2 fps | 18.2 fps |
| Bytes per frame | 7542 | 7542 |
| Difference | \<0.1% | — |
| Connection state | connected | streaming |

Both transports received an identical stream. This is the check that makes the
rest of the comparison meaningful.

### Jetson cost

| State | CPU | Power |
|---|---|---|
| Idle — nothing streaming | 75.4% | 27.38 W |
| Streaming both transports at once | 78.0% | 27.60 W |
| **Cost of the pipeline** | **+2.6%** | **+0.22 W** |

The measured cost covers JPEG decode, H264 encode, **and both transports
together**. Per transport it is smaller still — below what can be separated
from run-to-run noise on this hardware.

The 75.4% idle figure is the rest of the vehicle software, not streaming.
Without that baseline the streaming figures would look alarming and would be
wrong.

### For reference — synthetic source

A test-pattern run on the same setup, for contrast:

| Source | Bitrate | Frame rate | Bytes/frame |
|---|---|---|---|
| Test pattern | 100 kbps | 20.0 fps | 626 |
| ZED camera | 1098 kbps | 18.2 fps | 7542 |

A synthetic pattern compresses to almost nothing, so bitrate figures taken
from one say nothing about real use. Only the camera numbers are meaningful.

---

## 3. What the measurement shows

**Jetson load is not a differentiator.** Both transports drive the same
hardware encoder; the additional work is packetisation and, for WebRTC,
encryption. Together they cost 2.6% of CPU and 0.22 W. The common claim that
"RTSP is far lighter on the Jetson" is not supported by measurement on this
hardware.

**Bandwidth is not a differentiator.** Both carry the same H264 elementary
stream at the same bitrate. WebRTC adds roughly 10 bytes per packet for SRTP
authentication — on the order of 1% at this bitrate.

**On a local network they are equivalent.** Neither has an advantage worth
choosing on. The decision rests entirely on what happens off the LAN.

One note on the source: frames arrived at 18.2 fps against a 20 fps target,
because the ZED topic publishes at about 17-18 Hz. Both transports saw the
same rate, so the comparison is unaffected.

---

## 4. Outside a local network

The following is **reasoning from how the protocols work, not measurement**.
Testing it requires the production deployment with real SIMs.

### NAT traversal — the decisive difference

Vehicles run on M2M SIMs behind carrier NAT with no public address and no
inbound route. Every connection must be outbound.

WebRTC is built for this: ICE, STUN and TURN exist to establish a session
between two endpoints that can only dial out. RTSP assumes the client can
reach the server directly. Over the public internet, RTSP from a vehicle
requires a VPN on every vehicle and every viewer — which is a fleet-wide
deployment problem in itself.

This alone decides the question. The remaining points follow from it.

### Latency

On a LAN, both are fast; RTSP's reputation for 1-2 seconds is mostly player
buffering, and `ffplay` with `-fflags nobuffer -flags low_delay` gets well
under 200 ms.

Over a cellular link the gap opens up, and expected figures are:

| | WebRTC | RTSP |
|---|---|---|
| Typical | 150-400 ms | 1-5 s |
| Under congestion | degrades gradually | grows or stalls |

The mechanism, rather than the number, is the point. WebRTC has per-subscriber
congestion control: on a weak link it lowers bitrate and keeps latency bounded.
RTSP has none — it sends at the encoder's rate regardless of what the link can
carry, so a constrained uplink produces a growing queue, and latency climbs
until something drops. That behaviour is what makes RTSP unsuitable for
controlling a moving vehicle, more than any fixed millisecond figure.

**These numbers were not measured here and should be verified on the real
network before being quoted as results.**

### Control channel

WebRTC provides a bidirectional data channel on the same session, usable for
commands with per-message reliability settings. RTSP is one-way video with no
equivalent.

In the current design teleop rides MQTT rather than the video session, so RTSP
would not break it today. The difference matters for what becomes possible:
with WebRTC, control can be moved onto the media session — unordered and
unreliable, so stale commands are dropped rather than queued, which is what
cmd_vel wants. RTSP closes that option permanently.

### Other differences

| | WebRTC | RTSP |
|---|---|---|
| Browser playback | Native, no plugin | Needs a player or a conversion server |
| Encryption | Mandatory (SRTP/DTLS) | Optional, rarely deployed |
| Multiple viewers | SFU fans out; vehicle sends once | Needs a relay server, or the vehicle sends N copies |
| Adapts to weak viewer link | Per subscriber | No |

---

## 5. Conclusion

On a local network the two transports are equivalent: identical bitrate,
identical frame rate, and a combined cost of 2.6% CPU and 0.22 W that cannot
meaningfully be split between them. Nothing measured here favours either one.

The decision is made entirely outside the LAN, and there **WebRTC is the only
workable option** for this system:

1. Vehicles are behind carrier NAT and can only dial out. WebRTC handles this
   by design; RTSP would require a VPN across the whole fleet.
2. Cellular bandwidth varies continuously. WebRTC adapts per subscriber; RTSP
   sends blind and degrades into growing latency.
3. Operators watch in a browser. WebRTC plays natively; RTSP needs a player
   app or a conversion server.
4. More than one person watches at once. The SFU fans out from one vehicle
   stream; RTSP would need a relay anyway.
5. Video from vehicles in public spaces crosses the internet. WebRTC encrypts
   by default.

RTSP remains useful for one case, and it is worth keeping: a diagnostic feed
on the bench, same network, one viewer, player app acceptable. It is not a
candidate for remote fleet monitoring.

**Recommendation: WebRTC for the deployed system. No change to the current
architecture.**

---

## 6. Reproducing this

```bash
# Jetson — baseline first, with nothing streaming
./compare_stream.py --baseline --seconds 30

# then both transports at once
./compare_stream.py \
  --whip http://<server>:8070/w/<stream_key> \
  --rtsp rtsp://<server>:8554/bench \
  --source ros --topic /zed/zed_node/rgb/color/raw/image/compressed \
  --seconds 60 --label zed-both
```

Writes per-second CSV and a JSON summary to `results/`.

The baseline is not optional. Without it the reported CPU is the whole
machine, and streaming appears to cost thirty times what it does.
