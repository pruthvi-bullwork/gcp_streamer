#!/usr/bin/env python3
"""
Sample what a stream actually costs the Jetson.

Run it while a publisher is going, once per transport, then compare:

    ./measure.py --label webrtc --seconds 60
    ./measure.py --label rtsp   --seconds 60
    ./measure.py --compare

Reads tegrastats where available (CPU per core, GPU, encoder, RAM, power) and
falls back to psutil elsewhere. Writes a CSV per run and prints a summary.

The number that usually matters here is power, not CPU percentage: on a Jetson
the encoder is a separate block, so a pipeline can look idle on CPU while
drawing real watts.
"""

from __future__ import annotations

import argparse
import csv
import json
import pathlib
import re
import shutil
import statistics
import subprocess
import sys
import time

OUT = pathlib.Path(__file__).parent / "results"
OUT.mkdir(exist_ok=True)

CPU_RE = re.compile(r"CPU \[([^\]]+)\]")
GPU_RE = re.compile(r"GR3D_FREQ (\d+)%")
NVENC_RE = re.compile(r"NVENC (\d+)")
RAM_RE = re.compile(r"RAM (\d+)/(\d+)MB")
VDD_RE = re.compile(r"VDD_IN (\d+)mW")
CPUGPU_RE = re.compile(r"VDD_CPU_GPU_CV (\d+)mW")


def parse_tegrastats(line: str) -> dict | None:
    m = CPU_RE.search(line)
    if not m:
        return None
    loads = []
    for part in m.group(1).split(","):
        if part.startswith("off"):
            continue
        try:
            loads.append(float(part.split("%")[0]))
        except ValueError:
            pass
    row = {
        "cpu_avg": round(statistics.fmean(loads), 1) if loads else 0.0,
        "cpu_max": max(loads) if loads else 0.0,
    }
    if (g := GPU_RE.search(line)):
        row["gpu_pct"] = float(g.group(1))
    if (e := NVENC_RE.search(line)):
        row["nvenc_mhz"] = float(e.group(1))
    if (r := RAM_RE.search(line)):
        row["ram_mb"] = float(r.group(1))
    if (v := VDD_RE.search(line)):
        row["power_mw"] = float(v.group(1))
    if (c := CPUGPU_RE.search(line)):
        row["cpu_gpu_mw"] = float(c.group(1))
    return row


def sample_tegrastats(seconds: int):
    proc = subprocess.Popen(["tegrastats", "--interval", "1000"],
                            stdout=subprocess.PIPE, text=True)
    rows, deadline = [], time.time() + seconds
    try:
        while time.time() < deadline:
            line = proc.stdout.readline()
            if not line:
                break
            row = parse_tegrastats(line)
            if row:
                row["t"] = round(time.time(), 1)
                rows.append(row)
                print(f"\r  {len(rows)}/{seconds}s  cpu {row['cpu_avg']:5.1f}%  "
                      f"power {row.get('power_mw', 0)/1000:5.2f}W", end="", flush=True)
    finally:
        proc.terminate()
    print()
    return rows


def sample_psutil(seconds: int):
    try:
        import psutil
    except ImportError:
        sys.exit("no tegrastats and no psutil — pip install psutil")
    rows = []
    for i in range(seconds):
        rows.append({"t": round(time.time(), 1),
                     "cpu_avg": psutil.cpu_percent(interval=1),
                     "ram_mb": psutil.virtual_memory().used / 1e6})
        print(f"\r  {i+1}/{seconds}s  cpu {rows[-1]['cpu_avg']:5.1f}%",
              end="", flush=True)
    print()
    return rows


def summarise(rows: list[dict]) -> dict:
    def avg(k):
        vals = [r[k] for r in rows if k in r]
        return round(statistics.fmean(vals), 2) if vals else None

    def peak(k):
        vals = [r[k] for r in rows if k in r]
        return round(max(vals), 2) if vals else None

    return {
        "samples": len(rows),
        "cpu_avg_pct": avg("cpu_avg"),
        "cpu_peak_pct": peak("cpu_max") or peak("cpu_avg"),
        "gpu_avg_pct": avg("gpu_pct"),
        "nvenc_avg_mhz": avg("nvenc_mhz"),
        "ram_avg_mb": avg("ram_mb"),
        "power_avg_w": (avg("power_mw") / 1000) if avg("power_mw") else None,
        "power_peak_w": (peak("power_mw") / 1000) if peak("power_mw") else None,
    }


def run(label: str, seconds: int) -> None:
    have_tegra = shutil.which("tegrastats") is not None
    print(f"sampling '{label}' for {seconds}s "
          f"({'tegrastats' if have_tegra else 'psutil'})")
    print("  make sure the stream is already running and settled")
    rows = sample_tegrastats(seconds) if have_tegra else sample_psutil(seconds)
    if not rows:
        sys.exit("no samples collected")

    csv_path = OUT / f"{label}.csv"
    cols = sorted({k for r in rows for k in r})
    with csv_path.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        w.writerows(rows)

    summary = summarise(rows)
    (OUT / f"{label}.json").write_text(json.dumps(summary, indent=2))
    print(f"\n{label}:")
    for k, v in summary.items():
        if v is not None:
            print(f"  {k:16} {v}")
    print(f"\nwrote {csv_path}")


def compare() -> None:
    files = sorted(OUT.glob("*.json"))
    if len(files) < 2:
        sys.exit("need at least two runs — e.g. --label webrtc and --label rtsp")

    runs = {f.stem: json.loads(f.read_text()) for f in files}
    keys = ["cpu_avg_pct", "cpu_peak_pct", "gpu_avg_pct", "nvenc_avg_mhz",
            "ram_avg_mb", "power_avg_w", "power_peak_w"]

    names = list(runs)
    width = max(len(n) for n in names) + 2
    print("\n" + "metric".ljust(18) + "".join(n.ljust(width) for n in names))
    print("-" * (18 + width * len(names)))
    for k in keys:
        if all(runs[n].get(k) is None for n in names):
            continue
        row = k.ljust(18)
        for n in names:
            v = runs[n].get(k)
            row += (f"{v}" if v is not None else "-").ljust(width)
        print(row)

    if len(names) == 2:
        a, b = names
        pa, pb = runs[a].get("power_avg_w"), runs[b].get("power_avg_w")
        if pa and pb:
            diff = abs(pa - pb)
            pct = 100 * diff / max(pa, pb)
            print(f"\npower difference: {diff:.2f} W ({pct:.1f}%)")
            if pct < 5:
                print("Under 5% is inside run-to-run noise on a Jetson — treat "
                      "the two as equivalent on cost and decide on other grounds.")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--label", help="name for this run, e.g. webrtc or rtsp")
    ap.add_argument("--seconds", type=int, default=60)
    ap.add_argument("--compare", action="store_true")
    args = ap.parse_args()

    if args.compare:
        compare()
    elif args.label:
        run(args.label, args.seconds)
    else:
        ap.error("pass --label NAME or --compare")
