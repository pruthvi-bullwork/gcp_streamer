#!/usr/bin/env bash
# Run the agent at a named preset so settings can be compared like for like.
#
#   ./tune.sh list
#   ./tune.sh low          # 960x540 @ 20fps, 900 kbps
#   ./tune.sh balanced     # 1280x720 @ 20fps, 1200 kbps   <- suggested start
#   ./tune.sh high         # 1280x720 @ 30fps, 3000 kbps
#
# Method: start a preset here, then on the viewer page press "Record 60s" and
# drive the vehicle the way it will actually be used. The summary gives you
# average bitrate, packet loss and GB/hour for that preset. Compare, then put
# the winner into vehicle.env.
#
# Judge on packet loss first, picture quality second. A preset that looks
# sharper but loses 5% of packets is worse to steer by than a softer one that
# loses none.
set -euo pipefail
cd "$(dirname "$0")"
[ -f vehicle.env ] || { echo "no vehicle.env here"; exit 1; }

case "${1:-list}" in
  minimal)  W=640;  H=360; F=15; B=500  ;;
  low)      W=960;  H=540; F=20; B=900  ;;
  balanced) W=1280; H=720; F=20; B=1200 ;;
  smooth)   W=1280; H=720; F=30; B=2000 ;;
  high)     W=1280; H=720; F=30; B=3000 ;;
  list|*)
    cat <<'EOF'
preset     resolution   fps  kbps   GB/hour   6-hour session
minimal     640x360     15    500     0.23        1.4 GB
low         960x540     20    900     0.41        2.4 GB
balanced   1280x720     20   1200     0.54        3.2 GB
smooth     1280x720     30   2000     0.90        5.4 GB
high       1280x720     30   3000     1.35        8.1 GB

At 5 km/h the scene changes slowly, so H264 compresses it well and the lower
presets hold up better than the numbers suggest. Below 15 fps, motion gets
choppy enough to affect depth judgement when steering.

At a fixed bitrate, a lower resolution gets more bits per pixel — 960x540 at
1200 kbps looks sharper than 1280x720 at 1200 kbps. Worth comparing 'low' and
'balanced' directly rather than assuming 720p wins.

usage: ./tune.sh <preset>
EOF
    exit 0 ;;
esac

echo "preset ${1}: ${W}x${H} @ ${F}fps, ${B} kbps"
echo "expected: $(python3 -c "print(f'{$B*3600/8/1e6:.2f}')") GB/hour per stream"
echo

set -a; . ./vehicle.env; set +a
export WIDTH=$W HEIGHT=$H FPS=$F BITRATE_KBPS=$B
exec python3 vehicle_agent.py
