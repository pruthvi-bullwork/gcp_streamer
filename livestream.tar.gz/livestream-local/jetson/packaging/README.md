# Packaging the vehicle agent

Builds a Debian package that installs the agent, its fleet-wide config, and a
supervisor program. The only per-vehicle value is the vehicle id, which every
Jetson already has in `.env_vars`.

## Build

```bash
cd jetson/packaging
./build-deb.sh              # -> bullwork-livestream_1.0.0_all.deb
./build-deb.sh 1.0.1        # a specific version
```

Architecture-independent: it ships Python and config, and relies on the
GStreamer and ROS packages already present on the Jetson.

## What it installs

| Path | Purpose |
|---|---|
| `/opt/bullwork-livestream/vehicle_agent.py` | The agent |
| `/usr/bin/bullwork-livestream` | Launcher — layers config, sources ROS, execs the agent |
| `/etc/bullwork-livestream/fleet.env` | Fleet-wide constants. Marked a conffile, so an upgrade will not silently overwrite local edits |
| `/etc/supervisor/conf.d/bullwork-livestream.conf` | Supervisor program |

## Install on a vehicle

```bash
sudo dpkg -i bullwork-livestream_1.0.0_all.deb
sudo nano /etc/bullwork-livestream/fleet.env     # STREAM_API_URL + PROVISION_TOKEN
sudo supervisorctl reread && sudo supervisorctl update
sudo supervisorctl status bullwork-livestream
```

`postinst` installs paho-mqtt if it is missing and warns if `webrtcbin`,
`nicesrc` or the hardware encoder cannot be found — so a bad image is
reported at install time rather than on the first stream.

## Config layering

```
/etc/bullwork-livestream/fleet.env   sourced first — constants
$VEHICLE_ENV_FILE (.env_vars)        sourced second — wins
```

The agent reads the vehicle's existing names directly:

| In `.env_vars` | Used as |
|---|---|
| `VEHICLE_ID` | vehicle id, room name, MQTT topic prefix |
| `MQTT_BROKER_HOST` / `MQTT_BROKER_PORT` | broker (TLS implied by 8883) |
| `MQTT_USERNAME` / `MQTT_PASSWORD` | credentials |
| `MQTT_CLIENT_ID` | base for this agent's own client id, suffixed `-livestream` |

Nothing in `.env_vars` needs editing. The `-livestream` suffix matters: two
MQTT sessions sharing one client id disconnect each other in a loop.

## Operating

```bash
sudo supervisorctl start   bullwork-livestream
sudo supervisorctl stop    bullwork-livestream
sudo supervisorctl restart bullwork-livestream
sudo supervisorctl tail -f bullwork-livestream
```

Stopping the supervisor program stops the agent entirely — the vehicle then
ignores MQTT start commands. To stop a stream but stay reachable, send
`CMD_LIVESTREAM_DISABLE` instead.

## Changing settings fleet-wide

Edit `fleet.env`, bump the version, rebuild, redeploy. Bitrate, resolution,
framerate, camera topic and TURN server all live there. Because it is a
conffile, dpkg asks before replacing a file that was edited on the vehicle.

## Upgrading

```bash
sudo dpkg -i bullwork-livestream_1.0.1_all.deb
```

`prerm` stops the program, `postinst` reloads supervisor. No manual restart.
