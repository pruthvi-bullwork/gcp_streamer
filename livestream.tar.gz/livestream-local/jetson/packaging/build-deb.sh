#!/usr/bin/env bash
# Build the vehicle agent as a Debian package.
#
#   ./build-deb.sh              -> bullwork-livestream_1.0.0_all.deb
#   ./build-deb.sh 1.0.1        -> that version instead
#
# Install on a Jetson:
#   sudo dpkg -i bullwork-livestream_1.0.0_all.deb
#   sudo nano /etc/bullwork-livestream/fleet.env    # STREAM_API_URL + PROVISION_TOKEN
#   sudo supervisorctl reread && sudo supervisorctl update
#
# The package is architecture-independent — it is Python plus config, and the
# GStreamer and ROS pieces are already on the Jetson.
set -euo pipefail
cd "$(dirname "$0")"

VERSION=${1:-1.0.0}
PKG=bullwork-livestream
BUILD=$(mktemp -d)
trap 'rm -rf "$BUILD"' EXIT

install -d "$BUILD/DEBIAN"
install -d "$BUILD/opt/$PKG"
install -d "$BUILD/usr/bin"
install -d "$BUILD/etc/$PKG"
install -d "$BUILD/etc/supervisor/conf.d"

install -m 644 ../vehicle_agent.py "$BUILD/opt/$PKG/vehicle_agent.py"
install -m 755 bullwork-livestream "$BUILD/usr/bin/$PKG"
install -m 644 fleet.env           "$BUILD/etc/$PKG/fleet.env"
install -m 644 supervisor.conf     "$BUILD/etc/supervisor/conf.d/$PKG.conf"

cat > "$BUILD/DEBIAN/control" <<EOF
Package: $PKG
Version: $VERSION
Section: video
Priority: optional
Architecture: all
Depends: python3, python3-gi, python3-requests, gstreamer1.0-plugins-base,
 gstreamer1.0-plugins-good, gstreamer1.0-plugins-bad, gstreamer1.0-nice,
 gir1.2-gst-plugins-bad-1.0, supervisor
Recommends: gstreamer1.0-plugins-ugly, python3-paho-mqtt
Maintainer: Bullwork Mobility <engineering@bullworkmobility.com>
Description: Vehicle livestreaming agent
 Publishes the vehicle camera to the fleet livestreaming server over WHIP,
 under MQTT control. Reads the vehicle id and MQTT credentials from the
 vehicle's existing environment file, so the only per-vehicle value is the
 vehicle id it already has.
EOF

# Config the operator may edit is marked so dpkg does not overwrite it on
# upgrade without asking.
cat > "$BUILD/DEBIAN/conffiles" <<EOF
/etc/$PKG/fleet.env
/etc/supervisor/conf.d/$PKG.conf
EOF

cat > "$BUILD/DEBIAN/postinst" <<'EOF'
#!/bin/sh
set -e

# paho-mqtt is not packaged on every JetPack image; fall back to pip.
if ! python3 -c "import paho.mqtt.client" 2>/dev/null; then
  echo "installing paho-mqtt..."
  pip3 install --quiet paho-mqtt || \
    echo "WARNING: could not install paho-mqtt — do it manually before starting"
fi

for el in webrtcbin nicesrc; do
  gst-inspect-1.0 "$el" >/dev/null 2>&1 || \
    echo "WARNING: GStreamer element '$el' is missing — the agent cannot publish without it"
done

if ! gst-inspect-1.0 nvv4l2h264enc >/dev/null 2>&1; then
  echo "NOTE: nvv4l2h264enc not found — software encoding will be used"
fi

if [ -z "$(sed -n 's/^STREAM_API_URL=\(.\+\)/\1/p' /etc/bullwork-livestream/fleet.env)" ] ||
   [ -z "$(sed -n 's/^PROVISION_TOKEN=\(.\+\)/\1/p' /etc/bullwork-livestream/fleet.env)" ]; then
  echo
  echo "Set STREAM_API_URL and PROVISION_TOKEN in /etc/bullwork-livestream/fleet.env,"
  echo "then: supervisorctl reread && supervisorctl update"
  echo
fi

if command -v supervisorctl >/dev/null 2>&1; then
  supervisorctl reread  >/dev/null 2>&1 || true
  supervisorctl update  >/dev/null 2>&1 || true
fi
exit 0
EOF

cat > "$BUILD/DEBIAN/prerm" <<'EOF'
#!/bin/sh
set -e
if command -v supervisorctl >/dev/null 2>&1; then
  supervisorctl stop bullwork-livestream >/dev/null 2>&1 || true
fi
exit 0
EOF

cat > "$BUILD/DEBIAN/postrm" <<'EOF'
#!/bin/sh
set -e
if [ "$1" = "purge" ]; then
  rm -rf /etc/bullwork-livestream
fi
if command -v supervisorctl >/dev/null 2>&1; then
  supervisorctl reread >/dev/null 2>&1 || true
  supervisorctl update >/dev/null 2>&1 || true
fi
exit 0
EOF

chmod 755 "$BUILD/DEBIAN/postinst" "$BUILD/DEBIAN/prerm" "$BUILD/DEBIAN/postrm"

OUT="${PKG}_${VERSION}_all.deb"
dpkg-deb --build --root-owner-group "$BUILD" "$OUT" >/dev/null
echo "built $OUT"
dpkg-deb --contents "$OUT" | awk '{print $6}' | grep -v '/$'
