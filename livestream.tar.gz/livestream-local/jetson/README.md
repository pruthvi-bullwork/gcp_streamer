# Jetson + ZED 2i — vehicle side

Your `Livestreaming_CPP` node already does this job and is validated, so read
this first:

**If you're using your own node**, you don't need `vehicle_agent.py`. All you
need is to point it at the ZED and at the laptop:

```
camera topic  ->  /zed/zed_node/rgb/image_rect_color   (ZED ROS2 wrapper)
mqtt_host     ->  <laptop LAN IP>
vid           ->  vehicle-01
turn_server   ->  empty on a LAN
```

Then start at "Bring-up order" below and skip the rest.

**`vehicle_agent.py` is here as a standalone alternative** — same contract,
no ROS2 required, useful when you want to bisect a failure without your whole
stack in the picture, or to prove the server half works before the C++ node
is deployed. It implements exactly what `SERVER_API_SPEC.md` §1 specifies:
MQTT control on `{vid}/command/livestream`, non-trickle WHIP publish
with a Bearer token, relative `Location` resolution, `DELETE` on teardown,
and teleop with clamping and a deadman.

---

## Install

```bash
sudo mkdir -p /opt/vehicle-agent && sudo cp vehicle_agent.py /opt/vehicle-agent/
./install.sh                                  # deps + camera/encoder checks
sudo cp vehicle.env /etc/vehicle-agent.env    # edit MQTT_HOST and VID first
sudo cp vehicle-agent.service /etc/systemd/system/
sudo systemctl enable --now vehicle-agent
journalctl -u vehicle-agent -f
```

`install.sh` checks the thing that actually bites: **`gstreamer1.0-nice`**.
Without libnice, `webrtcbin` still shows up in `gst-inspect-1.0`, but building
any pipeline into it fails with `can't handle caps application/x-rtp`, which
reads like a caps problem and is not one. This cost me a debugging cycle
building this; it will cost you one too if the package is missing.

---

## Three video sources, in the order you should try them

`SOURCE` in `vehicle.env`:

**`test`** — `videotestsrc` with a burnt-in clock. No camera, no ROS. If this
reaches the viewer, then MQTT, WHIP, ICE, the encoder and the SFU are all
correct, and anything still broken is the camera. Always start here.

**`uvc`** — the ZED 2i as a plain UVC camera. No ZED SDK, no ROS2. The camera
delivers both eyes side by side in one frame (2560x720 for 720p per eye), so
the pipeline crops the right half away and publishes the left eye. Confirm
what your unit offers before trusting the defaults:

```bash
v4l2-ctl -d /dev/video0 --list-formats-ext
```

If it lists `YUYV 2560x720`, the defaults are right. This mode is the fastest
way to get real camera video flowing and it sidesteps the ZED SDK entirely.

**`ros`** — the ZED ROS2 wrapper, which is the real deployment path since you
presumably want depth, odometry and the rest anyway:

```bash
ros2 launch zed_wrapper zed_camera.launch.py camera_model:=zed2i
ros2 topic hz /zed/zed_node/rgb/image_rect_color     # confirm ~30 Hz first
```

The agent subscribes to that topic and pushes frames into `appsrc`. The
wrapper publishes `bgra8`; the agent maps ROS encodings to GStreamer formats
and sets caps from the first frame. Frames arriving while no session is
active are dropped rather than queued — a queue there turns into a latency
spike the moment someone starts watching.

One thing to know about this mode: ROS2 image transport of raw 720p BGRA is
about 110 MB/s over the loopback. It works, but it's the least efficient of
the three. If latency matters more than ROS integration, `uvc` is lighter.

---

## Bring-up order

On the laptop (`HOST_IP` must be its LAN address, not localhost):

```bash
./start.sh
./test/mqtt.sh watch          # separate terminal
```

On the Jetson:

```bash
sudo systemctl restart vehicle-agent
journalctl -u vehicle-agent -f
```

Back on the laptop:

```bash
./test/flow.sh start vehicle-01
```

What you should see, in order — each line tells you the previous hop worked:

1. laptop: `MQTT -> vehicle-01/command/livestream {...whip_url...}`
2. Jetson: `ENABLE -> http://<laptop>:8080/w/<key>`
3. Jetson: `ice-gathering-state: complete` then `WHIP 201, resource=...`
4. Jetson: `remote answer applied`
5. laptop: `webhook track_published` then `SSE ... -> STREAMING`
6. `flow.sh` prints a viewer URL

Stop at whichever step doesn't happen:

| Stops after | Look at |
|---|---|
| 1 | Jetson can't reach the broker. `mosquitto_sub -h <laptop> -t '#' -v` from the Jetson |
| 2 | Jetson can't reach port 8080 on the laptop. `curl -v http://<laptop>:8080/w` from the Jetson |
| 3 | WHIP rejected the offer — `docker logs lk-ingress` on the laptop has the reason |
| 4 | ICE failed. UDP 7885-7895 blocked on the laptop, or the answer's candidates are unreachable |
| 5 | livekit-server can't reach commander's webhook URL — check `HOST_IP` in `livekit-server.yaml` |

---

## Encoder

`nvv4l2h264enc` is used automatically when present, with baseline profile,
`insert-sps-pps=true` and a 2-second IDR interval. That last bit matters: a
viewer joining mid-stream sees nothing until the next keyframe, so a long
interval looks like "the stream is broken for new viewers."

If the log says `encoder: x264enc (software)`, the NVIDIA plugins aren't
visible to GStreamer. On JetPack that usually means `GST_PLUGIN_PATH` is
wrong or you're in a container without `/usr/lib/aarch64-linux-gnu/gstreamer-1.0`
mounted. Software encode will work, but the latency numbers will be the
laptop's worst case rather than the Jetson's, so don't draw conclusions about
§6 latency from a run that logged that warning.

---

## What I verified and what I didn't

`test/agent_selftest.py` (runs on any Linux box with GStreamer, no camera and
no LiveKit) drives this agent against a mock WHIP endpoint and asserts the
offer is complete non-trickle SDP with embedded candidates, `a=sendonly`,
H264, correct headers, relative `Location` resolved to absolute, and `DELETE`
on teardown. That all passes.

What it can't prove: that media actually flows into LiveKit's ingress, that
`nvv4l2h264enc` output is accepted as-is, and anything about the ZED. Those
need the real hardware — which is what the bring-up order above is for.
