#!/usr/bin/env bash
# Run on the Jetson. Safe on JetPack — nothing here replaces NVIDIA's own
# GStreamer plugins, it only adds the open-source ones alongside them.
set -euo pipefail

sudo apt-get update
sudo apt-get install -y \
  python3-gi python3-pip \
  gir1.2-gst-plugins-bad-1.0 \
  gstreamer1.0-tools \
  gstreamer1.0-plugins-base gstreamer1.0-plugins-good \
  gstreamer1.0-plugins-bad gstreamer1.0-plugins-ugly \
  gstreamer1.0-nice v4l-utils

pip3 install --user paho-mqtt requests

echo
echo "== checks =="
# gstreamer1.0-nice is the one that bites: without libnice, webrtcbin exists
# and inspects fine, but linking into it fails with a misleading
# "can't handle caps application/x-rtp" error at pipeline build time.
gst-inspect-1.0 nicesrc >/dev/null 2>&1 \
  && echo "libnice           : ok" \
  || { echo "libnice           : MISSING — webrtcbin will fail to link"; exit 1; }

gst-inspect-1.0 webrtcbin >/dev/null 2>&1 \
  && echo "webrtcbin         : ok" || { echo "webrtcbin         : MISSING"; exit 1; }

if gst-inspect-1.0 nvv4l2h264enc >/dev/null 2>&1; then
  echo "nvv4l2h264enc     : ok (hardware encode)"
else
  echo "nvv4l2h264enc     : missing — will fall back to x264enc (CPU, slower)"
fi

echo
echo "== cameras =="
for d in /dev/video*; do
  [ -e "$d" ] || continue
  echo "-- $d"
  v4l2-ctl -d "$d" --list-formats-ext 2>/dev/null | grep -E "\[|Size" | head -8
done
echo
echo "Set VIDEO_DEVICE in vehicle.env to whichever device lists a side-by-side"
echo "size like 2560x720 — that's the ZED."
