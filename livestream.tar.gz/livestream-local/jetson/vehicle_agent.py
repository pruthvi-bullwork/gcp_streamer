#!/usr/bin/env python3
"""
Vehicle agent — Jetson + ZED 2i.

Implements the vehicle half of the contract in SERVER_API_SPEC.md §1:

  subscribes  {vid}/command/livestream   ENABLE -> WHIP publish, DISABLE -> teardown
  subscribes  {vid}/command/teleop       {"lin":..,"ang":..} -> cmd_vel with deadman
  publishes   one WHIP session to the SFU, non-trickle ICE, Bearer auth

Always-on process: it connects to MQTT at boot and idles. MQTT never starts or
stops the process, only moves it in and out of a publish session.

Video source is selectable so you can bisect failures:
  SOURCE=test   videotestsrc              — no camera at all
  SOURCE=uvc    ZED 2i as a plain UVC cam — no ZED SDK, no ROS, left eye cropped
  SOURCE=ros    ZED ROS2 wrapper topic    — the real path

Encoder is nvv4l2h264enc when present (Jetson), x264enc otherwise.
"""

from __future__ import annotations

import json
import logging
import os
import signal
import sys
import threading
import time
from typing import Optional
from urllib.parse import urljoin

import gi

gi.require_version("Gst", "1.0")
gi.require_version("GstSdp", "1.0")
gi.require_version("GstWebRTC", "1.0")
from gi.repository import GLib, Gst, GstSdp, GstWebRTC  # noqa: E402

import paho.mqtt.client as mqtt  # noqa: E402
import requests  # noqa: E402

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s %(levelname)-5s %(name)s: %(message)s")
log = logging.getLogger("vehicle")

# --------------------------------------------------------------------------
# config (see vehicle.env)
# --------------------------------------------------------------------------

def env(*names: str, default: str = "") -> str:
    """First of several names that is set. Lets the agent read the vehicle's
    existing .env_vars (VEHICLE_ID, MQTT_USERNAME, ...) without renaming
    anything the rest of the vehicle stack depends on."""
    for n in names:
        v = os.environ.get(n)
        if v:
            return v
    return default


VID = env("VID", "VEHICLE_ID", default="vehicle-01")   # the only per-vehicle value
MQTT_HOST = env("MQTT_HOST", "MQTT_BROKER_HOST", default="127.0.0.1")
MQTT_PORT = int(env("MQTT_PORT", "MQTT_BROKER_PORT", default="1883"))
MQTT_USER = env("MQTT_USER", "MQTT_USERNAME")
MQTT_PASS = env("MQTT_PASS", "MQTT_PASSWORD")
# TLS is implied by 8883 unless told otherwise.
MQTT_TLS = env("MQTT_TLS", default="true" if MQTT_PORT == 8883 else "false").lower() == "true"
MQTT_CLIENT_ID = env("MQTT_CLIENT_ID", default=f"livestream-{VID}")

# Where this vehicle publishes. Two ways to set it:
#   1. Bake WHIP_URL/PUBLISH_TOKEN into this vehicle's config (provision by hand)
#   2. Leave them empty and set STREAM_API_URL + PROVISION_TOKEN — the vehicle
#      then asks for its own publish URL using its VID, so VID is the only
#      per-vehicle value and everything else is fleet-wide constant.
WHIP_URL = os.environ.get("WHIP_URL", "")
PUBLISH_TOKEN = os.environ.get("PUBLISH_TOKEN", "")
STREAM_API_URL = os.environ.get("STREAM_API_URL", "").rstrip("/")
PROVISION_TOKEN = os.environ.get("PROVISION_TOKEN", "")

AUTOSTART = os.environ.get("AUTOSTART", "false").lower() == "true"

SOURCE = os.environ.get("SOURCE", "test")          # test | uvc | ros
VIDEO_DEVICE = os.environ.get("VIDEO_DEVICE", "/dev/video0")
ZED_TOPIC = os.environ.get("ZED_TOPIC", "/zed/zed_node/rgb/image_rect_color")
# A topic ending in /compressed carries sensor_msgs/CompressedImage (JPEG).
# Override with ZED_TOPIC_COMPRESSED=true/false if your naming differs.
ZED_TOPIC_COMPRESSED = os.environ.get(
    "ZED_TOPIC_COMPRESSED",
    "true" if ZED_TOPIC.rstrip("/").endswith("compressed") else "false"
).lower() == "true"
CMD_VEL_TOPIC = os.environ.get("CMD_VEL_TOPIC", "/cmd_vel")

WIDTH = int(os.environ.get("WIDTH", "1280"))        # per eye, after cropping
HEIGHT = int(os.environ.get("HEIGHT", "720"))
FPS = int(os.environ.get("FPS", "30"))
BITRATE_KBPS = int(os.environ.get("BITRATE_KBPS", "3000"))

STUN_SERVER = os.environ.get("STUN_SERVER", "stun://stun.l.google.com:19302")
TURN_SERVER = os.environ.get("TURN_SERVER", "")     # turns://user:pass@host:443
ICE_GATHER_TIMEOUT_S = float(os.environ.get("ICE_GATHER_TIMEOUT_S", "10"))

MAX_LIN = float(os.environ.get("MAX_LIN", "1.0"))
MAX_ANG = float(os.environ.get("MAX_ANG", "1.5"))
DEADMAN_S = float(os.environ.get("DEADMAN_S", "0.5"))

TOPIC_LIVESTREAM = f"{VID}/command/livestream"
TOPIC_TELEOP = f"{VID}/command/teleop"


def have(element: str) -> bool:
    return Gst.ElementFactory.find(element) is not None


# --------------------------------------------------------------------------
# pipeline construction
# --------------------------------------------------------------------------

def source_branch() -> str:
    """Everything up to (and including) videoconvert, in system memory."""
    if SOURCE == "test":
        # A burnt-in clock makes glass-to-glass latency measurable with a
        # phone camera. Skipped if the pango plugin isn't installed.
        clock = ('timeoverlay halignment=right valignment=bottom '
                 'font-desc="Sans 28" ! ') if have("timeoverlay") else ""
        return (f"videotestsrc is-live=true pattern=ball ! "
                f"video/x-raw,width={WIDTH},height={HEIGHT},framerate={FPS}/1 ! "
                f"{clock}videoconvert")

    if SOURCE == "uvc":
        # A ZED 2i enumerates as a UVC camera delivering both eyes side by
        # side in one frame. Crop away the right half to get the left eye.
        # Check what your unit actually offers first:
        #   v4l2-ctl -d /dev/video0 --list-formats-ext
        full_w = WIDTH * 2
        return (f"v4l2src device={VIDEO_DEVICE} io-mode=2 ! "
                f"video/x-raw,format=YUY2,width={full_w},height={HEIGHT},framerate={FPS}/1 ! "
                f"videocrop right={WIDTH} ! videoconvert")

    if SOURCE == "ros":
        # Frames are pushed in by the rclpy subscriber below.
        if ZED_TOPIC_COMPRESSED:
            # JPEG in, H264 out. WebRTC cannot carry MJPEG, so the frames are
            # decoded and re-encoded — but on Jetson both halves run on
            # dedicated hardware, and only a few MB/s crosses loopback instead
            # of ~110 MB/s of raw pixels.
            if have("nvjpegdec"):
                log.info("decoder: nvjpegdec (Jetson hardware)")
                dec = "nvjpegdec"          # outputs NVMM, feeds nvvidconv directly
            else:
                log.warning("decoder: jpegdec (software)")
                dec = "jpegdec ! videoconvert"
            return ("appsrc name=rossrc is-live=true do-timestamp=true format=time "
                    "block=false max-bytes=8000000 ! jpegparse ! " + dec)
        return ("appsrc name=rossrc is-live=true do-timestamp=true format=time "
                "block=false max-bytes=8000000 ! videoconvert")

    raise SystemExit(f"unknown SOURCE={SOURCE!r} (test|uvc|ros)")


def encoder_branch() -> str:
    """Hardware encode on Jetson, software everywhere else."""
    if have("nvv4l2h264enc"):
        log.info("encoder: nvv4l2h264enc (Jetson hardware)")
        return (
            "nvvidconv ! video/x-raw(memory:NVMM),format=NV12 ! "
            f"nvv4l2h264enc bitrate={BITRATE_KBPS * 1000} "
            "control-rate=1 preset-level=1 profile=0 "
            f"iframeinterval={FPS * 2} idrinterval={FPS * 2} "
            "insert-sps-pps=true insert-vui=true maxperf-enable=true"
        )
    log.warning("encoder: x264enc (software) — expect higher latency than the Jetson path")
    return (
        f"x264enc tune=zerolatency speed-preset=ultrafast bitrate={BITRATE_KBPS} "
        f"key-int-max={FPS * 2} ! video/x-h264,profile=constrained-baseline"
    )


def build_pipeline_desc() -> str:
    return (
        f"{source_branch()} ! {encoder_branch()} ! "
        "h264parse config-interval=-1 ! "
        "video/x-h264,stream-format=byte-stream,alignment=au ! "
        "rtph264pay config-interval=-1 aggregate-mode=zero-latency pt=96 ! "
        "application/x-rtp,media=video,encoding-name=H264,payload=96,clock-rate=90000 ! "
        "webrtcbin name=whip bundle-policy=max-bundle latency=0"
    )


# --------------------------------------------------------------------------
# one WHIP publish session
# --------------------------------------------------------------------------

class WhipSession:
    def __init__(self, whip_url: str, token: str, on_dead) -> None:
        self.whip_url = whip_url
        self.token = token
        self.on_dead = on_dead
        self.resource_url: Optional[str] = None
        self.pipeline: Optional[Gst.Pipeline] = None
        self.webrtc = None
        self.appsrc = None
        self._offer_sent = False

    # -- lifecycle ---------------------------------------------------------

    def start(self) -> None:
        desc = build_pipeline_desc()
        log.info("pipeline: %s", desc)
        self.pipeline = Gst.parse_launch(desc)
        self.webrtc = self.pipeline.get_by_name("whip")
        self.appsrc = self.pipeline.get_by_name("rossrc")

        self.webrtc.set_property("stun-server", STUN_SERVER or None)
        if TURN_SERVER:
            # Without this, a vehicle behind carrier NAT may never connect.
            self.webrtc.emit("add-turn-server", TURN_SERVER)
            log.info("turn-server configured")

        self.webrtc.connect("on-negotiation-needed", self._on_negotiation_needed)
        self.webrtc.connect("notify::ice-gathering-state", self._on_ice_gathering)
        self.webrtc.connect("notify::connection-state", self._on_conn_state)

        bus = self.pipeline.get_bus()
        bus.add_signal_watch()
        bus.connect("message::error", self._on_bus_error)
        bus.connect("message::eos", lambda *_: self.stop("eos"))

        self.pipeline.set_state(Gst.State.PLAYING)
        GLib.timeout_add_seconds(int(ICE_GATHER_TIMEOUT_S) + 5, self._gather_watchdog)

    def stop(self, reason: str = "requested") -> None:
        log.info("session stopping (%s)", reason)
        if self.resource_url:
            try:
                requests.delete(self.resource_url,
                                headers={"Authorization": f"Bearer {self.token}"},
                                timeout=5)
                log.info("WHIP DELETE %s", self.resource_url)
            except Exception as exc:  # noqa: BLE001
                log.warning("WHIP DELETE failed: %s", exc)
            self.resource_url = None
        if self.pipeline:
            self.pipeline.set_state(Gst.State.NULL)
            self.pipeline = None
        self.webrtc = None
        self.appsrc = None

    # -- negotiation -------------------------------------------------------

    def _on_negotiation_needed(self, element) -> None:
        # WHIP is publish-only; announce sendonly or some servers reject the offer.
        trans = element.emit("get-transceiver", 0)
        if trans:
            trans.set_property(
                "direction", GstWebRTC.WebRTCRTPTransceiverDirection.SENDONLY)
        promise = Gst.Promise.new_with_change_func(self._on_offer_created, element, None)
        element.emit("create-offer", None, promise)

    def _on_offer_created(self, promise, element, _) -> None:
        reply = promise.get_reply()
        offer = reply.get_value("offer")
        element.emit("set-local-description", offer, Gst.Promise.new())
        log.info("local offer set, gathering ICE (non-trickle)")

    def _on_ice_gathering(self, element, _param) -> None:
        state = element.get_property("ice-gathering-state")
        log.info("ice-gathering-state: %s", state.value_nick)
        if state == GstWebRTC.WebRTCICEGatheringState.COMPLETE and not self._offer_sent:
            self._offer_sent = True
            threading.Thread(target=self._post_offer, daemon=True).start()

    def _gather_watchdog(self) -> bool:
        if not self._offer_sent and self.pipeline:
            log.error("ICE gathering never completed — aborting session")
            self.stop("ice gathering timeout")
            self.on_dead()
        return False

    def _post_offer(self) -> None:
        """Non-trickle: the full offer, all candidates embedded, one POST."""
        try:
            sdp = self.webrtc.get_property("local-description").sdp.as_text()
        except Exception as exc:  # noqa: BLE001
            log.error("no local description: %s", exc)
            return GLib.idle_add(self._fail)

        log.info("POST %s (%d bytes of SDP)", self.whip_url, len(sdp))
        try:
            r = requests.post(
                self.whip_url,
                data=sdp.encode(),
                headers={"Content-Type": "application/sdp",
                         "Authorization": f"Bearer {self.token}"},
                timeout=15,
            )
        except Exception as exc:  # noqa: BLE001
            log.error("WHIP POST failed: %s", exc)
            return GLib.idle_add(self._fail)

        if r.status_code not in (200, 201):
            log.error("WHIP POST -> %s: %s", r.status_code, r.text[:300])
            return GLib.idle_add(self._fail)

        # Location may be relative (LiveKit returns /w/<key>/<id>) — RFC 3986
        # resolve against the request URL.
        loc = r.headers.get("Location")
        self.resource_url = urljoin(r.url, loc) if loc else None
        log.info("WHIP %s, resource=%s", r.status_code, self.resource_url)
        GLib.idle_add(self._apply_answer, r.text)

    def _apply_answer(self, answer_sdp: str) -> bool:
        res, sdp = GstSdp.SDPMessage.new_from_text(answer_sdp)
        if res != GstSdp.SDPResult.OK:
            log.error("could not parse SDP answer")
            self._fail()
            return False
        answer = GstWebRTC.WebRTCSessionDescription.new(
            GstWebRTC.WebRTCSDPType.ANSWER, sdp)
        self.webrtc.emit("set-remote-description", answer, Gst.Promise.new())
        log.info("remote answer applied — media should be flowing")
        return False

    # -- health ------------------------------------------------------------

    def _on_conn_state(self, element, _param) -> None:
        state = element.get_property("connection-state")
        log.info("connection-state: %s", state.value_nick)
        if state in (GstWebRTC.WebRTCPeerConnectionState.FAILED,
                     GstWebRTC.WebRTCPeerConnectionState.CLOSED):
            self.stop(f"peer connection {state.value_nick}")
            self.on_dead()

    def _on_bus_error(self, _bus, msg) -> None:
        err, dbg = msg.parse_error()
        log.error("pipeline error: %s (%s)", err, dbg)
        self.stop("pipeline error")
        self.on_dead()

    def _fail(self) -> bool:
        self.stop("whip failed")
        self.on_dead()
        return False


# --------------------------------------------------------------------------
# optional ROS2 side: ZED frames in, cmd_vel out
# --------------------------------------------------------------------------

class RosBridge:
    """Only imported/started when SOURCE=ros. Keeps the agent usable without ROS."""

    def __init__(self, agent) -> None:
        import rclpy
        from geometry_msgs.msg import Twist
        from sensor_msgs.msg import CompressedImage, Image

        self.agent = agent
        self.Twist = Twist
        rclpy.init(args=None)
        self.node = rclpy.create_node("vehicle_agent")
        self.caps = None
        if ZED_TOPIC_COMPRESSED:
            self.node.create_subscription(CompressedImage, ZED_TOPIC,
                                          self._on_compressed, 1)
        else:
            self.node.create_subscription(Image, ZED_TOPIC, self._on_image, 1)
        self.cmd_pub = self.node.create_publisher(Twist, CMD_VEL_TOPIC, 1)
        log.info("ROS2: subscribing %s (%s), publishing %s", ZED_TOPIC,
                 "compressed JPEG" if ZED_TOPIC_COMPRESSED else "raw",
                 CMD_VEL_TOPIC)
        threading.Thread(target=lambda: rclpy.spin(self.node), daemon=True).start()

    def _on_compressed(self, msg) -> None:
        """JPEG frames go straight into the pipeline; jpegparse reads the
        dimensions out of the JPEG header, so no caps negotiation is needed."""
        sess = self.agent.session
        if not sess or not sess.appsrc:
            return
        if "jpeg" not in msg.format.lower():
            log.warning("unsupported compressed format %r — expected jpeg", msg.format)
            return
        if self.caps is None:
            self.caps = Gst.Caps.from_string(f"image/jpeg,framerate={FPS}/1")
            sess.appsrc.set_property("caps", self.caps)
        sess.appsrc.emit("push-buffer", Gst.Buffer.new_wrapped(bytes(msg.data)))

    _ROS_TO_GST = {"bgra8": "BGRA", "rgba8": "RGBA", "bgr8": "BGR",
                   "rgb8": "RGB", "mono8": "GRAY8"}

    def _on_image(self, msg) -> None:
        sess = self.agent.session
        if not sess or not sess.appsrc:
            return  # not publishing — drop the frame, don't queue it
        fmt = self._ROS_TO_GST.get(msg.encoding)
        if fmt is None:
            log.warning("unsupported image encoding %s", msg.encoding)
            return
        if self.caps is None:
            self.caps = Gst.Caps.from_string(
                f"video/x-raw,format={fmt},width={msg.width},height={msg.height},"
                f"framerate={FPS}/1")
            sess.appsrc.set_property("caps", self.caps)
        buf = Gst.Buffer.new_wrapped(bytes(msg.data))
        sess.appsrc.emit("push-buffer", buf)

    def publish_cmd_vel(self, lin: float, ang: float) -> None:
        t = self.Twist()
        t.linear.x = lin
        t.angular.z = ang
        self.cmd_pub.publish(t)


# --------------------------------------------------------------------------
# agent
# --------------------------------------------------------------------------

class Agent:
    def __init__(self) -> None:
        self.session: Optional[WhipSession] = None
        self.ros: Optional[RosBridge] = None
        self.loop = GLib.MainLoop()
        self._last_teleop = 0.0
        self._lock = threading.Lock()
        self._cached_publish: Optional[tuple] = None

    # -- MQTT --------------------------------------------------------------

    def on_connect(self, client, *_args) -> None:
        client.subscribe([(TOPIC_LIVESTREAM, 1), (TOPIC_TELEOP, 0)])
        log.info("MQTT connected, subscribed to %s and %s", TOPIC_LIVESTREAM, TOPIC_TELEOP)

    def on_message(self, _client, _userdata, msg) -> None:
        try:
            payload = json.loads(msg.payload.decode())
        except Exception:  # noqa: BLE001
            log.warning("undecodable payload on %s", msg.topic)
            return

        if msg.topic == TOPIC_LIVESTREAM:
            kind = payload.get("type")
            if kind == "CMD_LIVESTREAM_ENABLE":
                # BC's start command carries no payload: the vehicle already
                # knows where to publish, from its provisioned config. A
                # whip_url in the message still wins if one is sent.
                GLib.idle_add(self.enable,
                              payload.get("whip_url") or WHIP_URL,
                              payload.get("publish_token") or PUBLISH_TOKEN)
            elif kind == "CMD_LIVESTREAM_DISABLE":
                GLib.idle_add(self.disable)
            else:
                log.warning("unknown livestream command %r", kind)
        elif msg.topic == TOPIC_TELEOP:
            self.teleop(payload)

    # -- livestream --------------------------------------------------------

    def resolve_publish(self) -> tuple:
        """Return (whip_url, token). Configured values win; otherwise ask the
        Stream API for this vehicle's own endpoint. Cached after the first
        success so a later API outage does not stop a stream starting."""
        if WHIP_URL:
            return WHIP_URL, PUBLISH_TOKEN
        if self._cached_publish:
            return self._cached_publish
        if not (STREAM_API_URL and PROVISION_TOKEN):
            return None, ""
        url = f"{STREAM_API_URL}/{VID}/livestream/provision"
        try:
            r = requests.post(
                url, headers={"Authorization": f"Bearer {PROVISION_TOKEN}"}, timeout=10)
            r.raise_for_status()
            data = r.json()
            self._cached_publish = (data["whip_url"], data.get("publish_token", ""))
            log.info("provisioned from %s", STREAM_API_URL)
            return self._cached_publish
        except Exception as exc:  # noqa: BLE001
            log.error("could not provision from %s: %s", url, exc)
            return None, ""

    def enable(self, whip_url: Optional[str], token: str) -> bool:
        if not whip_url:
            whip_url, token = self.resolve_publish()
        if not whip_url:
            log.error("ENABLE but no publish URL. Set WHIP_URL, or set "
                      "STREAM_API_URL and PROVISION_TOKEN so this vehicle can "
                      "fetch its own.")
            return False
        with self._lock:
            if self.session:
                log.info("already publishing — restarting against the new URL")
                self.session.stop("re-enable")
                self.session = None
            log.info("ENABLE -> %s", whip_url)
            self.session = WhipSession(whip_url, token, self._session_died)
            try:
                self.session.start()
            except Exception as exc:  # noqa: BLE001
                log.exception("failed to start session: %s", exc)
                self.session = None
        return False

    def disable(self) -> bool:
        with self._lock:
            if self.session:
                self.session.stop("CMD_LIVESTREAM_DISABLE")
                self.session = None
            else:
                log.info("DISABLE with nothing publishing — no-op")
        return False

    def _session_died(self) -> None:
        with self._lock:
            self.session = None
        log.info("idle again, waiting for the next ENABLE")

    # -- teleop ------------------------------------------------------------

    def teleop(self, payload: dict) -> None:
        lin = payload.get("lin", payload.get("linear_x", payload.get("linear", 0.0)))
        ang = payload.get("ang", payload.get("angular_z", payload.get("angular", 0.0)))
        try:
            lin = max(-MAX_LIN, min(MAX_LIN, float(lin)))
            ang = max(-MAX_ANG, min(MAX_ANG, float(ang)))
        except (TypeError, ValueError):
            return
        self._last_teleop = time.monotonic()
        if self.ros:
            self.ros.publish_cmd_vel(lin, ang)

    def _deadman(self) -> bool:
        """No teleop message within DEADMAN_S -> publish a zero Twist."""
        if self.ros and self._last_teleop and \
                time.monotonic() - self._last_teleop > DEADMAN_S:
            self.ros.publish_cmd_vel(0.0, 0.0)
            self._last_teleop = 0.0
        return True

    # -- run ---------------------------------------------------------------

    def run(self) -> None:
        Gst.init(None)
        if SOURCE == "ros":
            self.ros = RosBridge(self)

        if AUTOSTART:
            # Benchmark / bench-test mode: publish immediately, no MQTT and no
            # BC. WHIP_URL must be set, or STREAM_API_URL + PROVISION_TOKEN.
            log.info("AUTOSTART — publishing without waiting for a command")
            GLib.idle_add(self.enable, WHIP_URL or None, PUBLISH_TOKEN)
            if not (WHIP_URL or (STREAM_API_URL and PROVISION_TOKEN)):
                log.error("AUTOSTART needs WHIP_URL (or STREAM_API_URL + PROVISION_TOKEN)")
            signal.signal(signal.SIGINT, lambda *_: (self.disable(), self.loop.quit()))
            signal.signal(signal.SIGTERM, lambda *_: (self.disable(), self.loop.quit()))
            try:
                self.loop.run()
            finally:
                pass
            return

        # Must differ from the vehicle stack's own MQTT_CLIENT_ID — a broker
        # disconnects the older session when a second one claims the same id.
        cid = f"{MQTT_CLIENT_ID}-livestream"
        client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=cid) \
            if hasattr(mqtt, "CallbackAPIVersion") else mqtt.Client(client_id=cid)
        if MQTT_USER:
            client.username_pw_set(MQTT_USER, MQTT_PASS)
        if MQTT_TLS:
            client.tls_set()          # system CA store; the broker uses a real cert
        client.on_connect = self.on_connect
        client.on_message = self.on_message
        client.will_set(f"{VID}/status/livestream", json.dumps({"online": False}), retain=True)
        client.connect_async(MQTT_HOST, MQTT_PORT, keepalive=30)
        client.loop_start()

        GLib.timeout_add(int(DEADMAN_S * 1000 / 2), self._deadman)

        def shutdown(*_):
            log.info("shutting down")
            self.disable()
            self.loop.quit()

        signal.signal(signal.SIGINT, shutdown)
        signal.signal(signal.SIGTERM, shutdown)

        log.info("vehicle agent idle — vid=%s source=%s broker=%s:%s",
                 VID, SOURCE, MQTT_HOST, MQTT_PORT)
        try:
            self.loop.run()
        finally:
            client.loop_stop()


if __name__ == "__main__":
    sys.exit(Agent().run())
