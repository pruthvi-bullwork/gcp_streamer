# Vehicle Livestreaming — How It Works

A plain overview of the four parts of the system, who talks to whom, and what
happens when someone asks to see a vehicle's camera.

---

## Part 1 — The four parts

### The Vehicle
A Jetson computer on the vehicle with a ZED camera attached. It is always
powered on and always connected, but it does not stream anything until it is
told to. When told, it captures the camera, compresses the video using its
hardware encoder, and sends out a single video stream.

### LiveKit (the media server)
The video server, running on a cloud machine. It receives one video stream
from a vehicle and copies it to everyone watching. Its job is only to move
video — it does not decide who is allowed to watch.

### The Stream API (our service)
The coordinator, running on the same cloud machine. It keeps track of which
vehicles are live, issues the access passes that let people watch, and ends
streams that nobody is watching. No video passes through it.

### Bullwork Commander (BC)
The main platform. It holds the users, decides who is allowed to see which
vehicle, sends the start and stop commands to vehicles, and hands the finished
stream link to the user's app or dashboard. It is the only part that deals
with people.

---

## Part 2 — Who talks to whom

| From | To | What is sent | How |
|---|---|---|---|
| BC | Vehicle | "Start streaming" | Messaging channel (MQTT) |
| Vehicle | LiveKit | The video itself | Direct video connection |
| LiveKit | Stream API | "Video has arrived" / "Video has stopped" | Automatic notification |
| BC | Stream API | "Give me a viewing pass" | Web request (HTTPS) |
| Stream API | BC | Stream link and access pass | Reply to the web request |
| BC | User | The stream link | However BC normally reaches its users |
| User | LiveKit | Watches the video | Direct video connection |

Three rules worth remembering:

**BC owns the vehicle command channel.** It already talks to every vehicle over
MQTT, so it sends the start and stop commands itself.

**The user never talks to our servers for video.** They get a link from BC and
connect straight to LiveKit. Video does not pass through BC or the Stream API.

**The vehicle only ever dials out.** Nothing connects *to* the vehicle. This is
what allows it to work over a mobile SIM with no fixed address.

---

## Part 3 — How it all works

### When the first person asks to watch

Someone opens a vehicle's camera in the app. BC checks they are allowed to,
then sends an MQTT command to that vehicle telling it to start streaming.

The vehicle receives the command, starts its camera, compresses the video and
begins sending it to LiveKit. LiveKit receives the stream and tells the Stream
API that video is now flowing. That notification is important: it is the only
proof that video is really arriving, rather than just having been requested.

BC then asks the Stream API for an access pass, gets back a link, and passes it
to the user. The user's browser connects straight to LiveKit and the video
appears.

Total time from click to video is a few seconds, most of it the vehicle
starting its camera.

### When a second person asks to watch

Nothing happens on the vehicle at all.

BC asks the Stream API for another access pass. The Stream API already knows
this vehicle is live, so it simply issues a new pass and returns a link. The
user connects to LiveKit and sees the same stream.

No MQTT command is sent. The vehicle is never contacted, never told anything,
and sends no extra video. LiveKit makes the copies.

This is the whole reason the system is built this way. The vehicle is on a
mobile connection with limited upload capacity. If it had to send a separate
copy of the video to each viewer, three or four people watching would be
enough to overwhelm it. Instead it sends one copy, always, no matter how many
people are watching, and the cloud server — which has far more bandwidth —
does the sharing.

### When someone stops watching

Viewers can simply close the page; the stream keeps running for anyone else
still watching.

To stop the stream entirely, BC sends a stop command to the vehicle over MQTT.
The vehicle shuts down its camera and video pipeline and goes back to waiting.
LiveKit notices the video has stopped and tells the Stream API, which marks the
vehicle as no longer live.

### Streams close themselves when nobody is watching

The system does not depend on anyone remembering to stop a stream. A laptop
that gets closed, a browser tab that crashes, an operator who walks away — none
of these send a stop command, and without a safeguard the vehicle would keep
streaming all day: burning its mobile data, running down the battery, and
costing bandwidth on the server. At fleet scale the failure compounds, because
every forgotten stream stays open at once.

So the Stream API watches how many people are actually connected to each live
stream. When a stream has had no viewers for ten minutes, the server ends it
itself — the vehicle's session is cut from the server side, so the vehicle
stops sending whether or not any client behaved correctly. Nothing needs to
ask it to.

This has a consequence every client has to handle: **a stream link that worked
earlier may no longer be live.** Clients must not assume a stream stays up
because it was up when they were given the link. Before showing a stream,
check whether it is still live, and if it is not, start it again — the same
first-viewer flow as before. The system reports the state through the Stream
API and through its live event feed, so a client can either check on demand or
listen for the change.

The ten-minute window is a setting, not a fixed rule, and can be shortened if
mobile data turns out to be the binding constraint.

### If something goes wrong

If the vehicle is told to stream but nothing arrives within a short window —
it is out of coverage, or the camera failed — the Stream API does not mark it
as live. The failure is reported so the system never claims a vehicle is
streaming when it is not, and BC can send a stop command to clear the
vehicle's state.

---

## Summary in one paragraph

BC knows the people and commands the vehicles. The Stream API tracks what is
live and hands out the passes. LiveKit moves the video. The vehicle sends one
stream and nothing more. Starting a stream involves the vehicle; watching one
does not.
