#!/usr/bin/env python3
"""
Offline check for vehicle_agent.py — no LiveKit, no MQTT, no camera.

Stands up a mock WHIP endpoint, drives the agent's enable() directly, and
asserts on what the agent actually sent: a complete non-trickle SDP offer,
sendonly direction, ICE candidates embedded, correct headers, and a relative
Location header resolved per RFC 3986.

  python3 test/agent_selftest.py

Proves the GStreamer plumbing and WHIP client are correct. Does NOT prove
media flows — that needs a real ingress (rung 3 in the README).
"""

import importlib.util
import os
import pathlib
import re
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer

os.environ.setdefault("SOURCE", "test")
os.environ.setdefault("WIDTH", "640")
os.environ.setdefault("HEIGHT", "480")
os.environ.setdefault("STUN_SERVER", "")        # no outbound STUN in CI
os.environ.setdefault("ICE_GATHER_TIMEOUT_S", "8")

ROOT = pathlib.Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("agent", ROOT / "jetson" / "vehicle_agent.py")
agent_mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(agent_mod)

from gi.repository import GLib  # noqa: E402

received = {}


def fake_answer(offer: str) -> str:
    """Turn the offer into a syntactically valid answer so set-remote-description
    has something real to parse. Media will not flow — that's not the point."""
    out = []
    for line in offer.splitlines():
        if line.startswith("a=setup:"):
            line = "a=setup:passive"
        elif line == "a=sendonly":
            line = "a=recvonly"
        elif line.startswith("a=ice-ufrag:"):
            line = "a=ice-ufrag:mock01"
        elif line.startswith("a=ice-pwd:"):
            line = "a=ice-pwd:mockmockmockmockmockmock"
        elif line.startswith("a=candidate:"):
            continue
        out.append(line)
    return "\r\n".join(out) + "\r\n"


class Handler(BaseHTTPRequestHandler):
    def do_POST(self):
        body = self.rfile.read(int(self.headers["Content-Length"])).decode()
        received["sdp"] = body
        received["content_type"] = self.headers.get("Content-Type")
        received["auth"] = self.headers.get("Authorization")
        answer = fake_answer(body).encode()
        self.send_response(201)
        self.send_header("Content-Type", "application/sdp")
        self.send_header("Content-Length", str(len(answer)))
        # Deliberately relative, like LiveKit's ingress.
        self.send_header("Location", "/w/testkey/session-42")
        self.end_headers()
        self.wfile.write(answer)

    def do_DELETE(self):
        received["deleted"] = self.path
        self.send_response(200)
        self.end_headers()

    def log_message(self, *_):
        pass


def check(label, cond, detail=""):
    print(f"  {'PASS' if cond else 'FAIL'}  {label} {detail}")
    if not cond:
        sys.exit(1)


def main():
    srv = HTTPServer(("127.0.0.1", 0), Handler)
    port = srv.server_port
    threading.Thread(target=srv.serve_forever, daemon=True).start()

    a = agent_mod.Agent()
    agent_mod.Gst.init(None)

    print("\n1. pipeline builds and negotiates")
    a.enable(f"http://127.0.0.1:{port}/w/testkey", "sk_testtoken")
    check("session created", a.session is not None)

    deadline = time.time() + 25
    ctx = GLib.MainContext.default()
    while time.time() < deadline and "sdp" not in received:
        ctx.iteration(False)
        time.sleep(0.02)
    check("offer was POSTed", "sdp" in received)

    sdp = received["sdp"]
    print("\n2. what the vehicle actually sent")
    check("content-type is application/sdp",
          received["content_type"] == "application/sdp")
    check("bearer token sent", received["auth"] == "Bearer sk_testtoken")
    check("H264 offered", "H264/90000" in sdp)
    check("sendonly direction", "a=sendonly" in sdp)
    check("non-trickle: candidates embedded",
          len(re.findall(r"^a=candidate:", sdp, re.M)) > 0,
          f"({len(re.findall(r'^a=candidate:', sdp, re.M))} candidates)")
    check("end-of-candidates or complete gathering",
          "a=end-of-candidates" in sdp or "a=candidate:" in sdp)

    print("\n3. relative Location resolved per RFC 3986")
    for _ in range(100):
        ctx.iteration(False)
        time.sleep(0.02)
    check("resource url absolute",
          a.session and a.session.resource_url == f"http://127.0.0.1:{port}/w/testkey/session-42",
          str(a.session.resource_url if a.session else None))

    print("\n4. teardown issues WHIP DELETE")
    a.disable()
    for _ in range(50):
        ctx.iteration(False)
        time.sleep(0.02)
    check("DELETE sent to the resource url", received.get("deleted") == "/w/testkey/session-42")
    check("session cleared", a.session is None)

    print("\n5. DISABLE with nothing running is a no-op")
    a.disable()
    check("still idle", a.session is None)

    srv.shutdown()
    print("\nAgent self-test passed (signalling only — media needs a real ingress).\n")


if __name__ == "__main__":
    main()
