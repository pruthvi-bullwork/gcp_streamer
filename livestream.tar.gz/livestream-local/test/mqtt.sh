#!/usr/bin/env bash
# MQTT-side helpers — useful when the BC side publishes the commands itself
# and commander is only there to mint credentials.
#
#   ./test/mqtt.sh watch                                  # see every command topic
#   ./test/mqtt.sh enable vehicle-01              # ask commander for creds, publish by hand
#   ./test/mqtt.sh disable vehicle-01
#   ./test/mqtt.sh teleop vehicle-01 0.3 -0.1
set -euo pipefail
cd "$(dirname "$0")/.."
set -a; . ./stack.env; set +a

CMD=${1:-watch}; VID=${2:-vehicle-01}
BASE="http://localhost:${COMMANDER_PORT}"
AUTH="Authorization: Bearer ${COMMANDER_API_TOKEN}"

case "$CMD" in
  watch)
    echo "subscribing to +/+/command/# on ${MQTT_HOST}:${MQTT_PORT}"
    mosquitto_sub -h "$MQTT_HOST" -p "$MQTT_PORT" -v -t '+/command/#'
    ;;
  enable)
    # publish_mqtt=false => commander creates the ingress and returns the
    # payload but does NOT publish it. This is the handoff shape for the BC
    # side: they call this, then send the MQTT message from their own system.
    RESP=$(curl -sS -X POST "$BASE/$VID/livestream?publish_mqtt=false" -H "$AUTH")
    echo "$RESP" | jq .
    PAYLOAD=$(echo "$RESP" | jq -c .mqtt_payload)
    TOPIC=$(echo "$RESP" | jq -r .mqtt_topic)
    echo "publishing to $TOPIC"
    mosquitto_pub -h "$MQTT_HOST" -p "$MQTT_PORT" -t "$TOPIC" -m "$PAYLOAD"
    ;;
  disable)
    mosquitto_pub -h "$MQTT_HOST" -p "$MQTT_PORT" \
      -t "$VID/command/livestream" -m '{"type":"CMD_LIVESTREAM_DISABLE"}'
    ;;
  teleop)
    LIN=${3:-0.2}; ANG=${4:-0.0}
    echo "sending cmd_vel at 10 Hz for 3 s (deadman will stop the vehicle after)"
    for _ in $(seq 1 30); do
      mosquitto_pub -h "$MQTT_HOST" -p "$MQTT_PORT" \
        -t "$VID/command/teleop" -m "{\"lin\":$LIN,\"ang\":$ANG}"
      sleep 0.1
    done
    ;;
  *) echo "usage: $0 {watch|enable|disable|teleop} [vid] [lin] [ang]"; exit 1 ;;
esac
