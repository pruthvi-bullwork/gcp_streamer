"""
Offline self-test for the Stream API — no LiveKit, no Redis, no MQTT broker.

Drives the real handlers through the flow BC will use:

  provision -> expect -> (webhook) -> STREAMING -> extra viewer -> reconcile

  python3 test/commander_selftest.py
  requires: pip install fakeredis httpx
"""

import base64
import hashlib
import importlib.util
import json
import os
import pathlib
import sys
import time
from datetime import datetime, timedelta, timezone

import jwt

KEY, SECRET = "devkey", "s" * 48
os.environ.update(
    HOST_IP="192.168.1.50",
    LIVEKIT_API_KEY=KEY,
    LIVEKIT_API_SECRET=SECRET,
    COMMANDER_API_TOKEN="dev-operator-token",
    PUBLISH_TIMEOUT_S="2",
    RECONCILE_EVERY_S="3600",      # off during the test
    IDLE_CLOSE_S="600",
    REDIS_URL="redis://localhost:6379/15",
)

ROOT = pathlib.Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("stream_api", ROOT / "commander" / "app.py")
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

import fakeredis.aioredis  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

AUTH = {"Authorization": "Bearer dev-operator-token"}
VID = "vehicle-01"
ROOM = VID


class FakeIngress:
    ingress_id = "IN_test123"
    stream_key = "sk_abcdef123456"


async def fake_ensure_ingress(vid):
    return FakeIngress()


def signed(body: str) -> str:
    now = datetime.now(timezone.utc)
    return jwt.encode(
        {"iss": KEY, "nbf": now, "exp": now + timedelta(minutes=5),
         "sha256": base64.b64encode(hashlib.sha256(body.encode()).digest()).decode()},
        SECRET, algorithm="HS256")


def webhook(client, event: str) -> None:
    body = json.dumps({"event": event, "room": {"name": ROOM},
                       "participant": {"identity": f"vehicle-{VID}"},
                       "id": "evt-1", "createdAt": int(time.time())})
    r = client.post("/system/webhooks/livekit", content=body,
                    headers={"Authorization": signed(body),
                             "Content-Type": "application/webhook+json"})
    assert r.status_code == 200, r.text


def check(label, cond, detail=""):
    print(f"  {'PASS' if cond else 'FAIL'}  {label} {detail}")
    if not cond:
        sys.exit(1)


def main() -> None:
    with TestClient(m.app) as client:
        m.ensure_ingress = fake_ensure_ingress
        m.redis = fakeredis.aioredis.FakeRedis(decode_responses=True)

        print("\n1. provision — once per vehicle")
        r = client.post(f"/{VID}/livestream/provision", headers=AUTH)
        body = r.json()
        check("returns whip_url", body["whip_url"].endswith("/w/sk_abcdef123456"),
              body["whip_url"])
        check("returns publish token", body["publish_token"] == "sk_abcdef123456")
        check("idempotent",
              client.post(f"/{VID}/livestream/provision",
                          headers=AUTH).json()["whip_url"] == body["whip_url"])

        print("\n2. auth and input validation")
        check("401 without bearer",
              client.post(f"/{VID}/livestream/provision").status_code == 401)
        # '+' is an MQTT single-level wildcard; a dot or space would also let a
        # caller shape a topic it should not reach.
        for bad in ("veh+bad", "veh.bad", "veh bad"):
            check(f"rejects vid {bad!r}",
                  client.post(f"/{bad}/livestream/provision",
                              headers=AUTH).status_code == 400)

        print("\n3. token is refused before the stream is live")
        r = client.post(f"/{VID}/livestream/token", headers=AUTH)
        check("409 when not streaming", r.status_code == 409, r.text)

        print("\n4. BC sent its MQTT, now tells us to expect video")
        r = client.post(f"/{VID}/livestream/expect", headers=AUTH)
        check("state STARTING", r.json()["state"] == "STARTING")

        print("\n5. video arrives — webhook flips state")
        webhook(client, "track_published")
        st = client.get(f"/{VID}/livestream/state", headers=AUTH).json()
        check("state STREAMING", st["state"] == "STREAMING", st)

        print("\n6. extra viewers are a pure lookup")
        r = client.post(f"/{VID}/livestream/token?identity=viewer-1", headers=AUTH)
        tok = r.json()
        claims = jwt.decode(tok["token"], SECRET, algorithms=["HS256"])
        check("scoped to this room", claims["video"]["room"] == ROOM)
        check("subscribe only", claims["video"].get("canPublish") is False)
        check("unique identity per call",
              client.post(f"/{VID}/livestream/token",
                          headers=AUTH).json()["identity"] != tok["identity"])

        print("\n7. expect while already streaming is a no-op")
        r = client.post(f"/{VID}/livestream/expect", headers=AUTH)
        check("already_streaming", r.json().get("already_streaming") is True)

        print("\n8. vehicle stops — webhook clears state")
        webhook(client, "room_finished")
        st = client.get(f"/{VID}/livestream/state", headers=AUTH).json()
        check("state DISABLED", st["state"] == "DISABLED", st)

        print("\n9. watchdog when the vehicle never publishes")
        client.post(f"/{VID}/livestream/expect", headers=AUTH)
        time.sleep(float(os.environ["PUBLISH_TIMEOUT_S"]) + 1.5)
        st = client.get(f"/{VID}/livestream/state", headers=AUTH).json()
        check("state FAILED_TO_START", st["state"] == "FAILED_TO_START", st)

        print("\n10. forged webhook is rejected")
        r = client.post("/system/webhooks/livekit", content="{}",
                        headers={"Authorization": "Bearer nonsense"})
        check("401 on bad signature", r.status_code == 401)

    idle_close_test()

    print("\nAll Stream API self-tests passed.\n")


def idle_close_test() -> None:
    """The reconcile loop is what closes unwatched streams, so drive it
    directly with a fake LiveKit rather than through the HTTP client."""
    import asyncio

    print("\n11. unwatched streams are closed by the server")

    class Room:
        def __init__(self, name, participants, publishers):
            self.name = name
            self.num_participants = participants
            self.num_publishers = publishers

    class FakeLK:
        deleted = []

        def __init__(self, rooms):
            self._rooms = rooms
            self.room = self

        async def list_rooms(self, _req):
            return type("R", (), {"rooms": self._rooms})()

        async def delete_room(self, req):
            FakeLK.deleted.append(req.room)
            # A deleted room stops appearing in list_rooms, and the publisher
            # is disconnected. Without this the loop keeps seeing it as live.
            self._rooms = [r for r in self._rooms if r.name != req.room]

        async def aclose(self):
            return None

    async def run(participants, idle_close_s, seed_idle_since=None):
        FakeLK.deleted = []
        m.redis = fakeredis.aioredis.FakeRedis(decode_responses=True)
        m.IDLE_CLOSE_S = idle_close_s
        m.RECONCILE_EVERY_S = 0.2
        lk = FakeLK([Room(VID, participants, 1)])
        m.lk_client = lambda: lk
        extra = {"idle_since": seed_idle_since} if seed_idle_since else {}
        await m.write_state(VID, m.STATE_STREAMING, **extra)
        task = asyncio.create_task(m.reconcile_loop())
        await asyncio.sleep(6)        # loop sleeps 5s before its first pass
        task.cancel()
        return await m.read_state(VID), FakeLK.deleted

    # one publisher, one viewer -> left alone
    st, deleted = asyncio.run(run(participants=2, idle_close_s=0))
    check("stream with a viewer is not closed",
          st["state"] == "STREAMING" and not deleted, st)

    # publisher only, but not idle long enough yet -> left alone, timer started
    st, deleted = asyncio.run(run(participants=1, idle_close_s=600))
    check("unwatched stream starts an idle timer",
          st["state"] == "STREAMING" and st.get("idle_since") and not deleted, st)

    # publisher only, idle long enough -> closed server-side
    st, deleted = asyncio.run(
        run(participants=1, idle_close_s=600, seed_idle_since=time.time() - 700))
    # DISABLED clears the Redis key, so the reason travels on the SSE event
    # rather than in the stored state — a poller just sees DISABLED, which is
    # the signal BC acts on.
    check("unwatched stream is closed after the timeout",
          st["state"] == "DISABLED", st)
    check("room deleted in LiveKit", deleted == [VID], deleted)


if __name__ == "__main__":
    main()
