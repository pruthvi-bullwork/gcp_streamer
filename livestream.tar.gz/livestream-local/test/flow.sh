#!/usr/bin/env bash
# Simulates Bullwork Commander. Every command here is something BC will do in
# production: it owns the MQTT channel and calls the Stream API over HTTP.
#
#   ./test/flow.sh provision vehicle-01   # once per vehicle, at setup
#   ./test/flow.sh start     vehicle-01   # MQTT start + expect + token
#   ./test/flow.sh token     vehicle-01   # extra viewer, no MQTT
#   ./test/flow.sh state     vehicle-01
#   ./test/flow.sh watch     vehicle-01   # SSE feed
#   ./test/flow.sh stop      vehicle-01   # MQTT stop
set -euo pipefail
cd "$(dirname "$0")/.."
set -a; . ./stack.env; set +a

CMD=${1:-start}; VID=${2:-vehicle-01}
BASE="${STREAM_API_URL:-http://localhost:${COMMANDER_PORT}}"
AUTH="Authorization: Bearer ${COMMANDER_API_TOKEN}"
TOPIC="$VID/command/livestream"

viewer_url() {
  local token=$1
  echo
  echo "Open on any device that can reach the server:"
  echo "  http://${HOST_IP}:${VIEWER_PORT}/viewer.html?url=${LIVEKIT_WS_URL:-ws://${HOST_IP}:${LIVEKIT_PORT}}&token=${token}"
}

case "$CMD" in
  provision)
    # Run once per vehicle. Put whip_url and publish_token into its vehicle.env.
    curl -sS -X POST "$BASE/$VID/livestream/provision" -H "$AUTH" | jq .
    ;;

  start)
    # 1. BC sends its own MQTT command. No payload — the vehicle knows where
    #    to publish from its provisioned config.
    echo "MQTT -> $TOPIC"
    mosquitto_pub -h "$MQTT_HOST" -p "$MQTT_PORT" \
      -t "$TOPIC" -m '{"type":"CMD_LIVESTREAM_ENABLE"}'

    # 2. BC tells the Stream API to expect video, which arms the timeout.
    curl -sS -X POST "$BASE/$VID/livestream/expect" -H "$AUTH" | jq .

    # 3. BC waits for the stream to come up, then takes a viewing pass.
    echo "waiting for video..."
    RESP=$(curl -sS -X POST "$BASE/$VID/livestream/token?wait=true" -H "$AUTH")
    echo "$RESP" | jq .
    TOKEN=$(echo "$RESP" | jq -r '.token // empty')
    [ -n "$TOKEN" ] || { echo "stream did not come up — check the vehicle log"; exit 1; }
    viewer_url "$TOKEN"
    ;;

  token)
    # Extra viewer on a stream that is already live. No MQTT at all.
    RESP=$(curl -sS -X POST "$BASE/$VID/livestream/token" -H "$AUTH")
    echo "$RESP" | jq .
    TOKEN=$(echo "$RESP" | jq -r '.token // empty')
    [ -n "$TOKEN" ] || { echo "not streaming — run '$0 start $VID' first"; exit 1; }
    viewer_url "$TOKEN"
    ;;

  state) curl -sS "$BASE/$VID/livestream/state" -H "$AUTH" | jq . ;;
  watch) curl -sN "$BASE/$VID/livestream/events" -H "$AUTH" ;;

  stop)
    echo "MQTT -> $TOPIC"
    mosquitto_pub -h "$MQTT_HOST" -p "$MQTT_PORT" \
      -t "$TOPIC" -m '{"type":"CMD_LIVESTREAM_DISABLE"}'
    ;;

  *) echo "usage: $0 {provision|start|token|state|watch|stop} [vid]"; exit 1 ;;
esac
