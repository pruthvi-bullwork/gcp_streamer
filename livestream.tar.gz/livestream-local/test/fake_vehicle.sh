#!/usr/bin/env bash
# Stand in for the Jetson: publish a test pattern to the WHIP ingress so you
# can prove the server half works before any hardware is involved.
#
#   ./test/fake_vehicle.sh vehicle-01
#
# Asks commander for a real whip_url (?publish_mqtt=false so no vehicle gets
# a command), then pushes video into it with whatever WHIP-capable tool is on
# this machine.
set -euo pipefail
cd "$(dirname "$0")/.."
set -a; . ./stack.env; set +a

VID=${1:-vehicle-01}
RESP=$(curl -sS -X POST \
  "http://localhost:${COMMANDER_PORT}/${VID}/livestream?publish_mqtt=false" \
  -H "Authorization: Bearer ${COMMANDER_API_TOKEN}")
WHIP_URL=$(echo "$RESP" | jq -r .mqtt_payload.whip_url)
TOKEN=$(echo "$RESP" | jq -r .mqtt_payload.publish_token)
echo "whip_url: $WHIP_URL"

if gst-inspect-1.0 whipclientsink >/dev/null 2>&1; then
  echo "publishing with gstreamer whipclientsink (ctrl-c to stop)"
  exec gst-launch-1.0 -v \
    videotestsrc is-live=true pattern=ball ! \
    video/x-raw,width=1280,height=720,framerate=30/1 ! \
    timeoverlay halignment=right valignment=bottom font-desc="Sans 36" ! \
    videoconvert ! x264enc tune=zerolatency speed-preset=ultrafast bitrate=2000 key-int-max=60 ! \
    video/x-h264,profile=constrained-baseline ! h264parse ! rtph264pay config-interval=-1 ! \
    whipclientsink name=ws signaller::whip-endpoint="$WHIP_URL" signaller::auth-token="$TOKEN"

elif ffmpeg -hide_banner -muxers 2>/dev/null | grep -qw whip; then
  echo "publishing with ffmpeg whip muxer (ctrl-c to stop)"
  exec ffmpeg -hide_banner -re \
    -f lavfi -i "testsrc2=size=1280x720:rate=30,drawtext=text='%{localtime}':fontsize=48:x=20:y=20:fontcolor=white" \
    -c:v libx264 -preset ultrafast -tune zerolatency -profile:v baseline -g 60 -b:v 2M \
    -f whip "$WHIP_URL"

else
  cat <<EOF

No WHIP publisher found on this machine. Three ways forward:

1. OBS Studio 30+ — Settings > Stream > Service "WHIP"
     Server:     $WHIP_URL
     Bearer:     $TOKEN

2. GStreamer with gst-plugins-rs:
     sudo apt install gstreamer1.0-plugins-rs   # or build from gst-plugins-rs
     then re-run this script

3. Skip WHIP and test only the SFU + viewer path with the lk CLI:
     ./bin/lk room join --url http://localhost:${LIVEKIT_PORT} \\
       --api-key ${LIVEKIT_API_KEY} --api-secret "\$LIVEKIT_API_SECRET" \\
       --identity fake-vehicle --publish-demo "${VID}"
   (this publishes straight into the room, bypassing the ingress — good for
   checking tokens and the viewer page, useless for checking WHIP)

EOF
  exit 1
fi
