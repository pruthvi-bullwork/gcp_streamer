# Local livestream stack — laptop server, Jetson publisher

Everything the two design docs say does not exist yet, built to run on one
laptop: LiveKit + WHIP ingress + Redis + mosquitto, and a commander HTTP API
with the three endpoints and the webhook receiver from
`SERVER_API_SPEC.md` §4.

The vehicle side is already done and validated, so nothing here asks you to
change Jetson code. This side matches the contract exactly:

| Contract | Where it lives here |
|---|---|
| `{vid}/command/livestream` ENABLE/DISABLE | `commander/app.py` → `publish_mqtt()` |
| `{vid}/command/teleop` | `test/mqtt.sh teleop` (commander doesn't own teleop) |
| `whip_url` = `whip_base_url` + `/` + stream key | `ingress.yaml.template`, `start_livestream()` |
| Room name `{vid}` | `room_name()` |
| Unique viewer identity per connection | `mint_viewer_token()` — random suffix per call |

```
Jetson (already built)                  Your laptop
  ROS2 + GStreamer                        livekit-server   :7880  signaling + SFU
        │  ① WHIP POST (SDP)              livekit-ingress  :8080  WHIP terminator
        ├────────────────────────────────▶ redis           :6379
        │                                 mosquitto        :1883
        │  ② MQTT CMD_LIVESTREAM_ENABLE   commander        :8090  this repo
        ◀────────────────────────────────  viewer page     :8081
                                                │ ③ webhook track_published
  Phone/laptop browser ◀── viewer token ────────┘
```

---

## 1. Read this before anything else: can the Jetson reach your laptop?

This is the one thing that decides whether the setup works, and it is not a
code problem. `whip_base_url` gets baked into the MQTT payload, so whatever
address you put in `HOST_IP` is the address the Jetson will POST its SDP to.

**Same LAN / same wifi (recommended for validation).** Set `HOST_IP` to your
laptop's LAN address (`ip -4 addr`). This is exactly the two-machine setup
already proven in the vehicle-side test log. Start here even if the real
deployment is cellular.

**Jetson on a cellular/M2M SIM, laptop on home wifi.** It will not work
as-is: your laptop has no public address, and the SIM is almost certainly
behind carrier-grade NAT. Two options:

- *Tailscale on both machines* (easiest). Install on the laptop and the
  Jetson, set `HOST_IP` to the laptop's `100.x.y.z` tailnet address. Media
  then rides the tailnet, which removes the NAT problem entirely — and also
  hides it, so this proves your pipeline works but proves nothing about
  whether the real deployment needs TURN.
- *A cloud VM instead of the laptop.* Same files, `use_external_ip: true`,
  plus the TLS/TURN block from `SERVER_API_SPEC.md` §2.3. That's the
  production path, not the validation path.

Do not try to test symmetric-NAT behaviour from a laptop. STUN-only looks
fine on every network that isn't a carrier, and the failure it hides is
total (no connection at all, not slow video) — `SERVER_API_SPEC.md` §5.7 is
right about this and nothing in this local setup changes it.

---

## 2. Install and run

```bash
./setup.sh          # once: docker, mosquitto, binaries, venv, writes stack.env
nano stack.env      # check HOST_IP is the address the Jetson can reach
./start.sh          # renders configs, starts everything detached
./stop.sh
```

`start.sh` prints a health line for each service and `logs/` gets a file per
process. The ingress runs in Docker with `--network host` (its ICE agent
needs real UDP ports); everything else runs natively.

Firewall, if ufw is on:

```bash
sudo ufw allow 1883/tcp && sudo ufw allow 7880:7881/tcp && sudo ufw allow 8080/tcp
sudo ufw allow 8081/tcp && sudo ufw allow 8090/tcp
sudo ufw allow 50100:50200/udp && sudo ufw allow 7885:7895/udp
```

---

## 3. Validation ladder

Each rung is independently checkable. Don't skip — when the full chain fails,
the only fast way to localise it is knowing which rung last passed.

### Rung 0 — logic only, no hardware, no services

```bash
./.venv/bin/python test/commander_selftest.py   # server side
python3 test/agent_selftest.py                  # vehicle side (needs GStreamer)
```

The first fakes LiveKit, Redis and MQTT and drives the real handlers through
cold start → webhook → STREAMING → warm join → teardown → watchdog timeout.
The second drives `jetson/vehicle_agent.py` against a mock WHIP endpoint and
checks the offer it produces. Both pass. If either fails, nothing downstream
is worth debugging.

### Rung 1 — services up and reachable

```bash
curl -s localhost:8090/healthz | jq .
curl -s localhost:7880                      # -> "OK"
curl -s -o /dev/null -w '%{http_code}\n' localhost:8080/w   # ingress alive
docker logs lk-ingress | tail               # must show it connected to redis
mosquitto_sub -h localhost -t '#' -v &      # then publish anything
```

From a **second device on the network**, repeat with `$HOST_IP` instead of
`localhost`. If that fails, it's the firewall, and every later rung will
fail confusingly.

### Rung 2 — WHIP path, without the Jetson

```bash
./test/fake_vehicle.sh vehicle-01     # pushes a test pattern via WHIP
./test/flow.sh token vehicle-01       # prints a ready-made viewer URL
```

Open the printed URL. Moving ball + a burnt-in timestamp means ingress, SFU,
token minting and the viewer page are all correct. Point a phone camera at
the screen next to the source clock to eyeball glass-to-glass latency.

If no WHIP publisher is installed the script prints three alternatives
(OBS 30+ is the quickest).

### Rung 3 — the real Jetson + ZED 2i

Set the Jetson up per `jetson/README.md` — that covers the ZED wiring, the
three selectable video sources, and a step-by-step "stops after step N means
look here" table. Point it at the laptop (`MQTT_HOST=$HOST_IP`), start with
`SOURCE=test` before involving the camera, then on the laptop:

```bash
./test/mqtt.sh watch &            # separate terminal — see the actual traffic
./test/flow.sh start vehicle-01
```

`flow.sh start` publishes `CMD_LIVESTREAM_ENABLE`, polls until the
`track_published` webhook lands, then prints the viewer URL. What to watch:

1. `mqtt.sh watch` shows the ENABLE payload with a real `whip_url`.
2. The Jetson log shows a `201` from the WHIP POST.
3. `docker logs -f lk-ingress` shows the session and ICE completing.
4. Commander logs `webhook track_published` → `SSE ... -> STREAMING`.

Any rung that stalls tells you which hop to look at — step 2 failing is
almost always `HOST_IP` unreachable from the Jetson, step 3 failing is ICE.

### Rung 4 — the behaviours the design doc actually cares about

```bash
# warm join: second viewer, vehicle untouched
./test/flow.sh token vehicle-01
./test/mqtt.sh watch     # must stay silent while that token is minted

# state feed
./test/flow.sh watch vehicle-01

# failure path: stop the Jetson process, then
./test/flow.sh start vehicle-01   # -> FAILED_TO_START after 25s, auto-DISABLE

# teardown
./test/flow.sh stop vehicle-01
```

Open the viewer URL on two devices at once with different identities and
confirm the Jetson's outbound bitrate doesn't change. That's the whole
argument for the SFU, and it's cheap to verify.

---

## 4. What the BC side needs from you

They have two shapes to choose from; commander supports both.

**Commander publishes the MQTT** (default, matches the architecture doc):

```
POST http://<HOST_IP>:8090/vehicle-01/livestream
Authorization: Bearer <COMMANDER_API_TOKEN>
```

**They publish the MQTT themselves** (`?publish_mqtt=false`): commander
creates the ingress and returns the exact payload to send, without touching
the broker. `test/mqtt.sh enable` demonstrates this end to end.

Either way the viewer call is the same, and it never involves the vehicle
when a stream is already up:

```
POST /vehicle-01/livestream/token?identity=<unique-per-session>
→ { "url": "ws://<HOST_IP>:7880", "token": "<jwt>", "room": "vehicle-01" }
```

Also available: `DELETE /{vid}/livestream`,
`GET /{vid}/livestream/state`, and an SSE feed at
`GET /{vid}/livestream/events` emitting
`STARTING` / `STREAMING` / `DISABLED` / `FAILED_TO_START`.

Tell them the identity rule explicitly: **unique per concurrent viewer**. A
shared identity silently kicks the previous viewer off, and it looks like a
server bug when it happens.

---

## 5. Decisions made here that the docs left open

- **`publish_token` is the ingress stream key.** LiveKit's WHIP endpoint
  authenticates on the stream key, so the bearer header the vehicle already
  sends is exactly right. No separate token to mint or expire, which also
  means the "short-lived" part of the spec isn't true yet — rotating means
  deleting and recreating the ingress.
- **`track_published` is the state trigger, not `room_started`.** A room can
  exist with no media. Only a published track means video is real.
- **Webhooks are JWT-verified, not HMAC.** LiveKit signs with a JWT carrying
  a SHA-256 of the body; `WebhookReceiver` checks both. The architecture doc
  says HMAC — same guarantee, different mechanism, no shared secret to
  invent.
- **Ingresses are reused per room.** `ensure_ingress()` lists before
  creating, so restarting a stream doesn't leak ingress objects. Dev builds
  that skip this end up with hundreds of them.
- **Commander doesn't own teleop.** The spec puts cmd_vel on MQTT; that's a
  BC-side publisher, so there's only a test helper here. If you decide to
  duplicate deadman/clamp server-side (architecture doc §7), commander is
  where it would go.

---

## 6. When it doesn't work

| Symptom | Cause |
|---|---|
| Jetson gets connection refused on the WHIP POST | `HOST_IP` isn't reachable from the vehicle, or 8080 is firewalled |
| WHIP returns 201 but no video, no webhook | ICE failed — check `docker logs lk-ingress`; usually the UDP range 7885-7895 is blocked |
| `timed out while waiting for ICE candidate gathering` | a stale session holding a port. The port *range* in `ingress.yaml` prevents this; a single `udp_port` reintroduces it |
| Viewer connects, black video, no errors | viewer token is for a different room, or nothing is publishing — check `flow.sh state` |
| Viewer page won't connect from a phone | you opened an `https` page against a `ws://` URL. Use the bundled `viewer.html` over plain http |
| Second viewer kicks the first off | both used the same identity |
| Stuck in `STARTING` forever | webhook can't reach commander. `HOST_IP` in the `webhook.urls` of `livekit-server.yaml` must be reachable *from livekit-server* |
| Everything worked, now nothing does | leftover processes from a previous run. `./stop.sh`, check the "still running" line is empty, `./start.sh` |

**Latency** (the open issue in `SERVER_API_SPEC.md` §6): the viewer page
shows jitter buffer delay, fps, bitrate and decode counts in the footer. If
lag grows while jitter buffer grows with it, the delay is receive-side, not
the encoder — chasing codec settings won't help. Check `ps aux` for
duplicate publishers before anything else; that was a real contributor last
time. The laptop's software x264 path is a worst case and shouldn't be used
to predict the Jetson's `nvv4l2h264enc` numbers.

---

## 7. What this is not

Dev-grade, deliberately: no TLS, no TURN, one node, a fixed API key, anonymous
MQTT, and a single shared bearer token for the whole HTTP API. Before a real
vehicle on a real SIM depends on it, you need at minimum the TLS + built-in
TURN block from `SERVER_API_SPEC.md` §2.3 (a real domain, not an IP), real
MQTT auth, and per-user auth on commander. Redis here is db 1 of the same
instance LiveKit uses — production should separate them, per the architecture
doc §6.
